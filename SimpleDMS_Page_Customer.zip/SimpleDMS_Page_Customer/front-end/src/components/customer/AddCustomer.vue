<template>
    <!-- AddCustomer.vue -->
    <div class="submit-form">
      <!-- 새 양식 폼 시작 -->
      <div v-if="!submitted">
        <!-- 성 -->
        <div class="form-group">
          <label for="lastName">Last Name</label>
          <input
            type="text"
            class="form-control"
            id="email"
            required
            v-model="customer.lastName"
            name="lastName"
          />
        </div>
        
        <!-- 이름 -->
        <div class="form-group">
          <label for="firstName">First Name</label>
          <input
            type="text"
            class="form-control"
            id="firstName"
            required
            v-model="customer.firstName"
            name="firstName"
          />
        </div>
        
        <!-- 이메일 -->
        <div class="form-group">
          <label for="email">Email</label>
          <input
            type="text"
            class="form-control"
            id="email"
            required
            v-model="customer.email"
            name="email"
          />
        </div>
  
        <!-- 휴대전화 -->
        <div class="form-group">
          <label for="phone">Phone</label>
          <input
            class="form-control"
            id="phone"
            required
            v-model="customer.phone"
            name="phone"
          />
        </div>
  
        <button @click="saveCustomer" class="btn btn-success">Submit</button>
      </div>
      <!-- 새 양식 폼 끝 -->
  
      <div v-else>
        <h4>You submitted successfully!</h4>
        <button class="btn btn-success" @click="newCustomer">Add</button>
      </div>
    </div>
  </template>
  
  <script>
  // axios 공통함수 import 
  import CustomerDataService from "../../services/CustomerDataService";
  
  export default {
    data() {
      return {
        customer: {
          lastName: "",     //string 은 초기값세팅 "" (int 는 null)
          firstName: "",
          email: "",
          phone: "",
          cid: null
        },
        // submit 버튼을 클릭하면 true 가 되고, You submitted successfully! 화면에 출력됨
        submitted: false
      };
    },
    methods: {
      saveCustomer() {
        // 임시 객체 변수 -> springboot 전송
        // 번호는(cid) 자동생성되므로 빼고 전송함
        let data = {
          lastName: this.customer.lastName,
          firstName: this.customer.firstName,
          email: this.customer.email,
          phone: this.customer.phone,
        };
  
        // insert 요청 함수 호출(axios 공통함수 호출)
        CustomerDataService.create(data)
        // 성공하면 then() 결과가 전송됨
        .then(response => {
          this.customer.cid = response.data.cid;
          // 콘솔 로그 출력(response.data)
          console.log(response.data);
          // 변수 submitted 
          this.submitted = true;
        })
        // 실패하면 .catch() 결과가 전송됨
        .catch(e => {
          console.log(e);
        })
  
      },
      newCustomer() {
        // 새양식 다시 보여주기 함수, 변수 초기화
        this.submitted = false;
        this.customer = {}
      }
    },
  };
  </script>
  
  <style>
    .submit-form {
      max-width: 300px;
      margin: auto;
    }
  </style>
  