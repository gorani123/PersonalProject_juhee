// EmpDataService.js
// 목적 : Emp 정보를 axios 로 CRUD 를 하는 공통 함수들 정의
import http from "../http-common";

class EmpDataService {
    // 모든 사원정보 조회 요청 함수 + 사원명 검색 요청 함수 
    // ename : 사원명 
    // page : 현재 페이지 번호 
    // size : 한 페이지당 화면에 표시할 데이터 갯수
    getAll(ename, page, size) {
        //   alert("확인용2")
    
            // get 방식 통신 요청 -> @GetMapping("/api/dept")
            // 1) 전체 조회 와
            // 2) 사원명 조회를 같이 하는 함수 getAll
            return http.get(`/emp?ename=${ename}&page=${page}&size=${size}`); 
        }

    // 사원번호로 조회 요청 함수
    // get 방식 통신 요청 -> @GetMapping("/api/emp/{eno}"), @PathVariable
    get(eno) {
        return http.get(`/emp/${eno}`)
    }

    // 사원정보 생성(insert) 요청 함수
    // post 방식 통신 요청 -> @PostMapping("/api/emp"), @RequestBody
    create(data) {
        return http.post("/emp", data);
    }

    // 사원정보 수정(update) 요청 함수
    // put 방식 통신 요청 -> @PutMapping("/api/emp/{eno}"), @RequestBody
    update(eno, data) {
        return http.put(`/emp/${eno}`, data);
    }

    // 사원정보 삭제(delete) 요청 함수
    // delete 방식 통신 요청 -> @DeleteMapping("/api/emp/deletion/{eno}")
    //                        , @PathVariable  
    delete(eno) {
        return http.delete(`/emp/deletion/${eno}`);
    }

    // 사원정보 전체 삭제 요청 함수
    // delete 방식 통신 요청 -> @DeleteMapping("/api/emp/all")
    deleteAll() {
        return http.delete("/emp/all")
    }

    // // 사원명 검색 요청 함수
    // // 쿼리스트링 방식 url : ?변수명=값&변수명2=값2....
    // // get 방식 통신 요청 -> @GetMapping("/api/emp") , @RequestParam
    // findByEname(ename) {
    //     return http.get(`/emp?ename=${ename}`);
    // }

}

export default new EmpDataService();