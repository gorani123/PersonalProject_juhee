package com.example.simpledms.service;

import com.example.simpledms.model.Dept;
import com.example.simpledms.repository.DeptRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * packageName : com.example.simpledms.service
 * fileName : DeptServiceTest
 * author : juhee
 * date : 2022-11-04
 * description : dept Service 테스트
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-04         juhee          최초 생성
 */
// 참고) 컨트롤러 테스트 어노테이션
//@WebMvcTest(controllers = DeptController.class)
//@ExtendWith(SpringExtension.class)
    
// @ExtendWith(가짜객체) : 테스트를 위한 url 관련 기능 제공
// @ExtendWith(MockitoExtension.class) : spring 기능이 필요없으므로 가짜객체(MockitoExtension.class)만 이용
//    순수하게 단위 테스트만 실행하면 됨
@ExtendWith(MockitoExtension.class)
class DeptServiceTest {

    // @Mock 붙이면 가짜 리파지토리 생성
    @Mock
    private DeptRepository deptRepository;  

    // @InjectMocks : 위에서 만든 가짜 리파지토리를 사용해서 서비스(DeptService)를 쓸 수 있게 함
    @InjectMocks
    private DeptService deptService;


    //    findAll() 테스트
    @DisplayName("findAll() : 서비스, 조회 함수")
    @Test
    void findAll() {
//        0. 가짜 데이터 넣기
        List<Dept> list = new ArrayList<>();

        list.add(Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );
        list.add(Dept.builder()
                .dno(20)
                .dname("ACCOUNTING")
                .loc("BUSAN")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );

//        1. given() : 기대값 설정  _given -> Alt + Insert (org.mockito) 선택
        given(deptRepository.findAll()).willReturn(list);   // 리파지토리, findAll()함수 부르고, 리턴 기대값으로 list가 나올것

//        2. 테스트 실행
        List<Dept> list2 = deptService.findAll();   // findAll() 테스트 결과를 list2 배열에 넣기

//        3. 결과 검증(검토) : asert()_구버전복잡, assertThat()_간단
        //           assertThat(테스트실행값).비교함수(기댓값) : 일치하면 테스트 통과, 불일치하면 실패
        assertThat(list2.get(0).getDname()).isEqualTo(list.get(0).getDname());
        assertThat(list2.get(1).getDname()).isEqualTo(list.get(1).getDname());
        // findAll() 결과값이 든 배열 list2   비교함수   list.get() 원래데이터(가짜데이터로 넣은 값)
    }


    //    removeAll() 테스트
    @DisplayName("removeAll() : 서비스, 모두 삭제 함수")
    @Test
    void removeAll() {
//        1. 테스트 실행
        deptService.removeAll();

//        2. 위의 함수가 몇 번 실행되었는지 확인
        // verify(리파지토리객체, times(실행횟수)) : 함수 실헹 횟수 점검  .. times -> 자동임포트, Mockito.times 선택
        verify(deptRepository, times(1)).deleteAll();
    }


    //    save() 테스트
    @DisplayName("save() : 서비스, 부서정보 생성 함수")
    @Test
    void save() {
        // insert 필요하니까 가짜 객체 생성
//        1. 기대값 설정 : deptRepository 객체 이용
        Dept dept = Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build();

        // given 설정 : 가짜 데이터를 통해 결과 미리 예측
        given(deptRepository.save(any()))
                .willReturn(dept);  // 위에 만들어놓은 가짜데이터를 리턴

//        2. 테스트 실행(서비스의 save()함수 실행)
        Dept dept2 = deptService.save(dept);

//        3. 테스트 결과 점검/검토
        assertThat(dept2.getDname()).isEqualTo(dept.getDname());
    }

    
    @DisplayName("findById() : 서비스, dno로 부서정보 조회 함수")
    @Test
    void findById() {
//        1. 기댓값 설정
        // 원본
        Optional<Dept> optionalDept = Optional.ofNullable(Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build());  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

        given(deptRepository.findById(anyInt())).willReturn(optionalDept);

        //        ++) 서비스함수가 실행되면서 기댓값이 변경 (_해킹) 이 붙음 (DeptService 데이터가공 후 실험하기)
                // 비교대상
                Optional<Dept> optionalDept3 = Optional.ofNullable(Dept.builder()
                        .dno(10)
                        .dname("SALES_해킹123")
                        .loc("SEOUL")
                        .build());

//        2. 테스트 실행
        Optional<Dept> optionalDept2 = deptService.findById(anyInt());

//        3. 결과 검토/검증
        assertThat(optionalDept2.get().getDname())
                .isEqualTo(optionalDept.get().getDname());
//                .isEqualTo(optionalDept3.get().getDname()); // 원본의 "SALES"와 ++)비교대상의 "SALES_해킹" 다르니까 오류 뜸
    }


    @DisplayName("removeById() : 서비스, 부서번호로 삭제 함수")
    @Test
    void removeById() {
//        1. given() : 가정, 전제, 기댓값 설정
        given(deptRepository.existsById(anyInt())).willReturn(true);    // 리파지토리가 가짜니까 미리 값을 넣어야 실행할 수 있음
        
//        2. 테스트 실행
        boolean bSuccessed = deptService.removeById(anyInt());  // 서비스함수 삭제 실행

//        3. 몇 번 실행되었는지 검토, true가 나오는지 검토
        verify(deptRepository, times(1)).deleteById(anyInt());  // deptRepository의 deleteById 함수가 1번 실행된 거 맞니?
        assertThat(bSuccessed).isEqualTo(true);     //bSuccessed 테스트 결과가 true 맞으면 통과
    }

    @DisplayName("findAllByDnameContaining() : 서비스, 부서명으로 검색하는 함수")
    @Test
    void findAllByDnameContaining() {
//        1. 기댓값 설정
        List<Dept> list = new ArrayList<>();

        list.add(Dept.builder().dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build()
                );
        list.add(Dept.builder().dno(20)
                .dname("ACCOUNTING")
                .loc("PUSAN")
                .build()
        );

        given(deptRepository.findAllByDnameContaining(any())).willReturn(list);

//        2. 테스트 실행
        List<Dept> list2 = deptService.findAllByDnameContaining(any());

//        3. 테스트 검증
        assertThat(list2.get(0).getDname()).isEqualTo("SALES");
        assertThat(list2.get(1).getDname()).isEqualTo("ACCOUNTING");
        assertThat(list2.get(0).getLoc()).isEqualTo("SEOUL");
        assertThat(list2.get(1).getLoc()).isEqualTo("PUSAN");


    }
}