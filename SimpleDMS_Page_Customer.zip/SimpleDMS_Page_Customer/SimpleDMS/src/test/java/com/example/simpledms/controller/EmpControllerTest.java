package com.example.simpledms.controller;

import com.example.simpledms.model.Emp;
import com.example.simpledms.service.EmpService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

/**
 * packageName : com.example.simpledms.controller
 * fileName : EmpControllerTest
 * author : juhee
 * date : 2022-11-04
 * description : emp 컨트롤러 함수 테스트
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-04         juhee          최초 생성
 */
// @ExtendWith(SpringExtension.class) : 컨트롤러 테스트를 위한 어노테이션(테스트를 위한 url 관련 기능 제공)
@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = EmpController.class)
class EmpControllerTest {

    // 가짜 객체 받기
    @Autowired
    private MockMvc mockMvc;

    // 만들어진 가짜객체를 empService에 넣기
    @MockBean
    private EmpService empService;

    // 잭슨(jackson) 객체 생성(build.gradle 에서 설치 후)
    // : 객체(모델) to Json, Json to 객체(모델) 로 자동 변환해주는 라이브러리
    ObjectMapper objectMapper = new ObjectMapper();


    //   getEmpAll() 함수 테스트
    @DisplayName("getEmpAll() : 부서 전체 조회 함수 테스트") // @DisplayName: 테스트시 왼쪽알림창에 뜸. 가독성을 위해 사용, 없어도 상관없음
    @Test
    void getEmpAll() throws Exception {
//       1. given() : 결과 예측치 정의
        List<Emp> list = new ArrayList<>();

        // 가짜 데이터로 예측치 설정
        list.add(Emp.builder()      // Emp 모델에 @Build , @AllArgsConstructor  걸어줘야 함!!
                .eno(8888)
                .ename("SAM")
                .job("TEACHER")
                .hiredate("1982-01-23 00:00:00")
                .salary(1800)
                .dno(10)
                .build()
        );
        list.add(Emp.builder()
                .eno(8889)
                .ename("홍길동")
                .job("THIEF")
                .hiredate("1982-01-01 00:00:00")
                .salary(2800)
                .dno(10)
                .build()
        );
        given(empService.findAll())
                .willReturn(list);  // 위에 만들어놓은 가짜데이터를 리턴

//        2. when 설정 : 실제 테스팅 실행 -> 결과 == 예측한 결과 같은지 확인 (동일하면OK, 틀리면 에러)
        mockMvc.perform(get("/api/emp"))    // 테스트 실행
                .andExpect(status().isOk())           // 테스트 결과 검토
                // 3. Content-Type 이 APPLICATION_JSON 인지?
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$.[0].ename").value("SAM"))
//                .andExpect(jsonPath("$.[1].ename").value("홍길동"))
                .andDo(print());    // 화면에 출력
    }

    //   getEmpId() 함수 테스트
    // 사원번호(eno)로 조회하면 한 건 나오니까 list 말고 걍 객체로 받기
    @DisplayName("getEmpId() : 사원번호로 조회 함수 테스트") // @DisplayName: 테스트시 왼쪽알림창에 뜸. 가독성을 위해 사용, 없어도 상관없음
    @Test
    void getEmpId() throws Exception{
//        1. 가짜 데이터 설정 및 기댓값 설정(전제)_(given()
        // Optional.ofNullable(객체) : Optional에 객체 넣기
        Optional<Emp> optionalEmp = Optional.ofNullable(Emp.builder()
                .eno(8888)
                .ename("SAM")
                .job("CLERK")
                .build());
        
        // 매개변수가 정수일 때 -> anyInt (아무 정수나 다 들어올 수 있음)
        given(empService.findById(anyInt()))
                .willReturn(optionalEmp);  // 위에 만들어놓은 가짜데이터를 리턴
        
//        2. when 설정 : 실제 테스팅 실행 -> 결과 == 예측한 결과 같은지 확인 (동일하면OK, 틀리면 에러)
        mockMvc.perform(get("/api/emp/8888"))
                // 3. 실행 후 OK 메시지 나오는지?
                .andExpect(status().isOk())
                .andDo(print());    // 결과 화면 출력
    }


    //   createEmp() 함수 테스트
    @DisplayName("createEmp() : 사원 생성 함수 테스트")
    @Test
    void createEmp() throws Exception {
//        1. 테스트를 위한 기대값 설정(가짜 데이터)
        Emp emp = Emp.builder()
                .eno(8889)
                .ename("홍길동")
                .job("THIEF")
                .hiredate("1982-01-01 00:00:00")
                .salary(2800)
                .dno(10)
                .build();

        given(empService.save(any()))
                .willReturn(emp);  // 1) 위에 만들어놓은 가짜데이터를 리턴

//        2. when 설정 : 실제 테스팅 실행
//        when(.perform()) / then(.andExpect())
        mockMvc.perform(post("/api/emp")    // 2) .perform() : 테스트 실행 함수
                        .contentType(MediaType.APPLICATION_JSON)
                       // objectMapper.writeValueAsString(객체) : 객체 to Json 변환 후, 또 문자열로 변환
                        .content(objectMapper.writeValueAsString(emp)))  // 아래 수동으로 치던 걸 알아서 Java Object를 JSON 문자열로 변환
                .andExpect(status().isOk()) // 3) .andExpect() : 테스트 결과 검토
                .andDo(print());
    }


    //   updateEmp() 함수 테스트
    @DisplayName("updateEmp() : 사원번호로 부서 수정 함수 테스트")
    @Test
    void updateEmp() throws Exception {
//        1. 가짜 데이터 설정
        Emp emp = Emp.builder()
                .eno(7369)
                .ename("SAM")
                .job("CLERK")
                .build();  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

//        2. given 설정
        given(empService.save(any()))
                .willReturn(emp);  // 위에 만들어놓은 가짜데이터를 리턴

//        3. when 설정 : 실제 테스팅 실행
        mockMvc.perform(put("/api/emp/7369")   // url 체크
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(emp)))
                .andExpect(status().isOk())     // 실행 후 ok메시지
                .andDo(print());    // print() : 테스트과정을 화면에 출력하는 함수

    }


    //   deleteEmp() 함수 테스트
    @DisplayName("deleteEmp() : 사원번호로 삭제 함수 테스트")
    @Test
    void deleteEmp() throws Exception {        // 예외처리
//        1) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // 리턴값 boolean
        given(empService.removeById(anyInt()))
                .willReturn(true);  // boolean -> 성공시 true

//        2) when 설정 : 실제 테스팅 실행
        // delete(삭제) -> DeleteMapping -> .perform(delete("주소"))
        mockMvc.perform(delete("/api/emp/deletion/7369")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }


    //   removeAll() 함수 테스트
    @DisplayName("deleteEmp() : 전체 삭제 함수 테스트")
    @Test
    void removeAll() throws Exception {
//        1. given() : 기댓값 설정(전제)
        // removeAll() 이 void 함수라서 리턴값이 없음. willReturn() 못씀
        // willDoNothing().given(서비스객체).함수명 : 리턴값이 없는 함수에 기댓값 설정하는 방법
        willDoNothing().given(empService).removeAll();

//        2. 테스트 실행 및 결과 검토 : mokMvx 이용
        mockMvc.perform(delete("/api/emp/all"))   // .perform() : 테스트 실행
                .andExpect(status().isOk())                 // .andExpect() : 테스트 결과 검토
                .andDo(print());                            // pring() : 테스트과정(결과) 화면 출력
    }
}