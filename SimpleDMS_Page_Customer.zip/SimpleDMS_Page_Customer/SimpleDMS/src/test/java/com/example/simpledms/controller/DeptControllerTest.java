package com.example.simpledms.controller;

import com.example.simpledms.model.Dept;
import com.example.simpledms.service.DeptService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jdk.net.SocketFlow;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * packageName : com.example.simpledms.controller
 * fileName : DeptControllerTest
 * author : juhee
 * date : 2022-11-03
 * description :                    J UNIT Controller 테스트
 *
 *          J UNIT 은 스프링부트에서 기본으로 제공함.
*           단위 테스트(기능/함수별 테스트) : J Unit 5 라이브러리 이용. 스프링부트 프로젝트를 생성하면 자동으로 J Unit 라이브러리가 설치됨
 *
 *          MVC 디자인패턴 안에서 테스팅:
 *              1) Controller 테스트
 *              2) Service 테스트
 *              3) Repository 테스트
 *
 *          MVC : 서로 역할 분리해서 코딩(폴더별) 가짜 객체(Mocking모킹 )이용
 *          테스팅 : MVC 클래스 간 의존관계를 끊어서 격리시켜 독립적으로 테스트하는게 핵심임
 *              1. 컨트롤러 테스트 : 서비스 객체역할을 대신하는 가짜 객체(Mocking)를 불러 테스트 함
 *                  @WebMvcTest(controllers = 대상컨트롤러이름.class)
 *                  @ExtendWith(SpringExtension.class 또는 가짜객체이름.class) : 테스팅시 스프링부터 기능 이용할 건지 설정
 *                  SpringExtension.class -> 스프링부트 기능 이용한다는 뜻. 다른거 적으면 이용 안한다는 뜻
 *                  MockMvc : 가짜 객체 클래스이름
 *                  --> @Autowired 로 (가짜)객체를 받아와야 함
 *                  @MockBean : 대상 변수에 가짜 객체(Autowired로 받은)를 넣어주는 어노테이션
 *
 *              2. 테스트 절차
 *                  1) 전제(given) : 테스트에 대한 사전 조건 정의(결과 기대값 미리 세팅(정의))
 *                              given(객체명.함수()).willreturn(기대값)
 *
 *                  2) 실행( when, perform() ) : 실제 테스트가 진행됨(when 절차. 테스트함수 perform 실행)
*                       perform(get(url))
 *                              : select -> get 방식(조회) 테스트 실행
 *                      perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json데이터))
 *                              : insert -> post 방식 테스트 실행
 *                      perform(put(url).contentType(MediaType.APPLICATION_JSON).content(json데이터))
 *                              : update -> put 방식 테스트 실행
 *                      perform(delete(url))
 *                              : delete 방식 테스트 실행
 *
 *                  3) 결과 점검( then, andExpect(점검함수) ) : 테스트 결과를 알려줌. 테스팅 결과 점검* _ andExpect(status().isOK())
 *                      점검함수 :
 *                              status().isOK() : 상태 메시지가 OK로 나오는가?
 *                              jsonPath(json_객체_경로).value(값) : json 객체 경로에 그 값이 있는가?
 *                              그 외 기타  header(), cookie(), view(), model() ...등등
 *                      참고) jsonPath() : json 객체의 경로를 탐색하는 라이브러리 함수
 *
 *                      $ : json의 루트 경로(가장 첫 지점)
 *                      .(닷) : 속성명에 접근하는 접근자
 *                          ex) {
 *                              "dname": "SALES",
 *                              "loc" : "SEOUL"
 *                              }
 *                              => jsonPath($.dname).value("SALES")  == "SALES"
 *                                제이선 객체의 dname 속성값이 SALES인가?      SALES 맞음
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-03         juhee          최초 생성
 */
// @ExtendWith(SpringExtension.class) : 컨트롤러 테스트를 위한 어노테이션(스프링 함수 또는 기능, url 관련 기능 제공)
@WebMvcTest(controllers = DeptController.class)
@ExtendWith(SpringExtension.class)
class DeptControllerTest {

    // 가짜 객체 받기
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DeptService deptService;    // deptService에 가짜객체 넣기


    // 잭슨(jackson) 객체 생성(build.gradle 에서 설치 후)
    // : 객체(모델) to Json, Json to 객체(모델) 로 자동 변환해주는 라이브러리
    ObjectMapper objectMapper = new ObjectMapper();


    //   getDeptAll() 함수 테스트
    @DisplayName("getDeptAll() : 부서 전체 조회 함수 테스트") // @DisplayName: 테스트시 왼쪽알림창에 뜸. 가독성을 위해 사용, 없어도 상관없음
    @Test
    void getDeptAll() throws Exception {                  // throws Exception으로 예외처리 보내기
//       --- 테스팅 절차 ---
//        1) 가짜 데이터 설정
        List<Dept> list = new ArrayList<>();
        // build 디자인 패턴 : 생성자를 대신해서 객체를 생성하는 기능. 생성자보다 사용하기 편함. Lombok에서도 지원함(@Builder)
        // 모델.builder()
        //    .속성()
        //    .속성2()
        //      ...
        //    .build()
        list.add(Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );
        list.add(Dept.builder()
                .dno(20)
                .dname("ACCOUNTING")
                .loc("BUSAN")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );

//        2) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // given에 빨간줄, alt + enter -> mock 들어간 걸로 선택
        given(deptService.findAll())
                .willReturn(list);  // 위에 만들어놓은 가짜데이터를 리턴


//        3) when 설정 : 실제 테스팅 실행 -> 결과 == 예측한 결과 같은지 확인 (동일하면OK, 틀리면 에러)
        // url, data, type을 위주로 체크
        //  1. url 점검 (api/dept 인지?)
        mockMvc.perform(get("/api/dept"))
                // 2. 실행 후 OK 메시지 나오는지?
                .andExpect(status().isOk())
                // 3. Content-Type 이 APPLICATION_JSON 인지?
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))  // content -> alt+insert , 두번째꺼 선택(servlet result)
                // 4. json 객체의 0번 데이터 dname이 "SALES"인지?
                .andExpect(jsonPath("$.[0].dname").value("SALES"))
                // 5. JSON 객체의 2번 데이터 DNAME이 "ACCOUNTING"인지?
                .andExpect(jsonPath("$.[1].dname").value("ACCOUNTING"))
                .andDo(print());
    }


    @DisplayName("deleteDept() : 전체 삭제 함수 테스트")
    @Test
    void removeAll() throws Exception {
//        1.given() : 기댓값 설정
        // removeAll() 이 void 함수라서 리턴값이 없음. willReturn() 못씀
        // willDoNothing().given(서비스객체).함수명 : 리턴값이 없는 함수에 기댓값 설정하는 방법
        willDoNothing().given(deptService).removeAll();

//        2. when 설정 : 실제 테스팅 실행
        mockMvc.perform(delete("/api/dept/all"))   // 테스트 실행
                .andExpect(status().isOk())                  // 테스트 결과 검토
                .andDo(print());
    }


    @DisplayName("createDept() : 부서 생성 함수 테스트")
    @Test
    void createDept() throws Exception {
//        1) 가짜 데이터 설정
        Dept dept = Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build();  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

//        2) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // save함수, 매개변수는 객체 -> any (정수일 경우만 anyInt)
        given(deptService.save(any()))
                .willReturn(dept);  // 위에 만들어놓은 가짜데이터를 리턴

//        3) when 설정 : 실제 테스팅 실행
        // insert(추가.생성) -> PostMapping -> .perform(post("주소"))
        // url, data, type을 위주로 체크
        mockMvc.perform(post("/api/dept")
                        .contentType(MediaType.APPLICATION_JSON)
//                       objectMapper.writeValueAsString(객체) : 객체 to Json 변환 후, 또 문자열로 변환
                .content(objectMapper.writeValueAsString(dept)))  // 아래 수동으로 치던 걸 알아서 Java Object를 JSON 문자열로 변환
//                        .content("{ \"dno\" : 10, \"dname\" : \"SALES\", \"loc\": \"SEOUL\"}"))
                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.dname").value("SALES"))
                .andDo(print());    // print() : 테스트과정을 화면에 출력하는 함수
    }


    //   getDeptId() 함수 테스트
    // 부서번호(dno)로 조회하면 한 건 나오니까 list 말고 걍 객체로 받기
    @DisplayName("getDeptAll() : 부서번호로 조회 함수 테스트") // @DisplayName: 테스트시 왼쪽알림창에 뜸. 가독성을 위해 사용, 없어도 상관없음
    @Test
    void getDeptId() throws Exception {                  // throws Exception으로 예외처리 보내기
//       --- 테스팅 절차 ---
//        1) 가짜 데이터 설정
//
//      getDeptAll() 함수에, Dept 객체가 Optional 처리돼어 있어서 Optional로 싸야 함.
//        1) Optional 객체에 넣기 함수 : Optional.ofNullable(객체);
//        2) Optional 객체에 뺴기 함수 : 옵셔널객체.get()
//        3) Optional 객체에 있는지 확인하는 함수 : 옵셔널객체.isPresent()
        Optional<Dept> optionalDept = Optional.ofNullable(Dept.builder()
                .dno(10)
                .dname("SALES")
                .loc("SEOUL")
                .build());  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

//        2) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // 매개변수가 정수일 때 -> anyInt
        given(deptService.findById(anyInt()))
                .willReturn(optionalDept);  // 위에 만들어놓은 가짜데이터를 리턴

//        3) when 설정 : 실제 테스팅 실행 -> 결과 == 예측한 결과 같은지 확인 (동일하면OK, 틀리면 에러)
        // url, data, type 위주로 체크
        //  1. url 점검 (api/dept/{dno} 인지?)
        mockMvc.perform(get("/api/dept/10"))
                // 2. 실행 후 OK 메시지 나오는지?
                .andExpect(status().isOk())
//                // 3. Content-Type 이 APPLICATION_JSON 인지?
//                .andExpect(content().contentType(MediaType.APPLICATION_JSON))  // content -> alt+insert , 두번째꺼 선택(servlet result)
//                // 4. json 객체의 0번 데이터 dname이 "SALES"인지?
//                .andExpect(jsonPath("$.dname").value("SALES"))
                // 5. JSON 객체의 2번 데이터 DNAME이 "ACCOUNTING"인지?
                .andDo(print());
    }


    @DisplayName("updateDept() : 부서번호로 부서 수정 함수 테스트")
    @Test
    void updateDept() throws Exception {  // perform 에러 뜨면 예외처리 해줘야 함
        //        1) 가짜 데이터 설정
        Dept dept = Dept.builder()
                .dno(10)
                .dname("SALES2")
                .loc("SEOUL2")
                .build();  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

//        2) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // save함수, 매개변수는 객체 -> any (정수일 경우만 anyInt)
        given(deptService.save(any()))
                .willReturn(dept);  // 위에 만들어놓은 가짜데이터를 리턴

//        3) when 설정 : 실제 테스팅 실행
        // update(수정) -> PutMapping -> .perform(put("주소"))
        // url(부서번호 넣어야 함), data, type 위주로 체크
        mockMvc.perform(put("/api/dept/10")    // put -> 빨간줄, MockMvcRequestBuilders.put 선택
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dept)))
//                        .content("{ \"dno\" : 10, \"dname\" : \"SALES\", \"loc\": \"SEOUL\"}"))
                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.dname").value("SALES2"))
                .andDo(print());    // print() : 테스트과정을 화면에 출력하는 함수
    }


    // 삭제 -> 결과값 true/false 이고 객체로 리턴값 안나오니까!
    @DisplayName("deleteDept() : 부서번호로 삭제 함수 테스트")
    @Test
    void deleteDept() throws Exception {        // 예외처리
        //        1) given 설정 : 가짜 데이터를 통해 결과 미리 예측
        // save함수, 매개변수는 객체 -> any (정수일 경우만 anyInt)
        given(deptService.removeById(anyInt()))
                .willReturn(true);  // boolean -> 성공시 true

//        2) when 설정 : 실제 테스팅 실행
        // delete(삭제) -> DeleteMapping -> .perform(delete("주소"))
        // url, data, type을 위주로 체크
        mockMvc.perform(delete("/api/dept/deletion/10")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }


}