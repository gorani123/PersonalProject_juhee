package com.example.simpledms.repository;

import com.example.simpledms.model.Dept;
import com.example.simpledms.model.Emp;
import com.example.simpledms.service.EmpService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

/**
 * packageName : com.example.simpledms.repository
 * fileName : EmpRepositoryTest
 * author : juhee
 * date : 2022-11-04
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-04         juhee          최초 생성
 */
// @ExtendWith(SpringExtension.class) : 테스트 할 때 스프링 함수 또는 기능을 제공하는 어노테이션
@ExtendWith(SpringExtension.class)
//@DataJpaTest : 리파지토리를 테스트하기 위한 어노테이션. 테스트 후 자동 롤백(rollback). DB 접속 필요
//                                                  RollBack : 데이터를 select/insert/update/delete 한 경우, 명령 취소
@DataJpaTest
//@AutoConfigureTestDatabase : DB 연결을 위한 어노테이션
// Replace.NONE : 스프링 부트의 내장 DB로 H데이터베이스가 있지만 -> 외장 DB인 오라클로 대체해서 접속,테스트한다는 옵션임(귀찮아서)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class EmpRepositoryTest {

    @Autowired
    private EmpRepository empRepository;

    @Test
    void findAllByEnameContaining() {
//        1) 가짜 데이터 설정
        Optional<Emp> empOptional = Optional.ofNullable(Emp.builder()
                .ename("홍길동")
                .job("SALES")
                .manager(8888)
                .hiredate("1982-01-23 00:00:00")
                .salary(1300)
                .build());

//        임시로 가짜 데이터를 insert
        empRepository.save(empOptional.get());

//        2) 테스트 실행
        List<Emp> list = empRepository.findAllByEnameContaining("홍길동");

//        3) 테스트 검증
        assertThat(list.get(0).getEname()).isEqualTo("홍길동");
    }


    //    save함수(JPA 기본제공) test
    @Test
    void save() {
//        1. 테스트 데이터 정의
        Optional<Emp> optionalEmp = Optional.ofNullable(Emp.builder()
                .ename("홍길동")
                .job("SALES")
                .manager(8888)
                .hiredate("1982-01-23 00:00:00")
                .salary(1300)
                .build());

//        2. 테스트 실행(조회함수 테스트)
        Emp emp2 = empRepository.save(optionalEmp.get());

//        3. 테스트 검증 (assertThat()_두번째꺼 선택)
        // 테스트 검증 후 자동으로 save()함수_insert 취소(rollback)
        assertThat(emp2.getEname()).isEqualTo("홍길동");
    }


    //    deleteAll함수(JPA 기본제공) test
    @Test
    void deleteAll() {
//        1. 테스트 데이터 정의
        Optional<Emp> optionalEmp = Optional.ofNullable(Emp.builder()
                .ename("홍길동")
                .job("SALES")
                .manager(8888)
                .hiredate("1982-01-23 00:00:00")
                .salary(1300)
                .build()
        );

        // 임시로 가짜 데이터 insert --> 테스트 후 자동 롤백
        empRepository.save(optionalEmp.get());

//        2. 테스트 실행(모두 삭제))
        empRepository.deleteAll();

//        3. 테스트 검증(emptyList() 나오면 성공)
        // 테스트 검증 후 자동으로 취소(rollback)
        assertThat(empRepository.findAll()).isEqualTo(Collections.emptyList());
    }


}