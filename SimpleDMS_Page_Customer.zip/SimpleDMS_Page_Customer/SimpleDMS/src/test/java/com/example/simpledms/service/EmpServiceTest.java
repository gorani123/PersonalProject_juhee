package com.example.simpledms.service;

import com.example.simpledms.model.Dept;
import com.example.simpledms.model.Emp;
import com.example.simpledms.repository.EmpRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * packageName : com.example.simpledms.service
 * fileName : EmpServiceTest
 * author : juhee
 * date : 2022-11-04
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-04         juhee          최초 생성
 */

// @ExtendWith(가짜객체) : 테스트를 위한 url 관련 기능 제공
// @ExtendWith(MockitoExtension.class) : spring 기능이 필요없으므로 가짜객체(MockitoExtension.class)만 이용
//    순수하게 단위 테스트만 실행하면 됨
@ExtendWith(MockitoExtension.class)
class EmpServiceTest {

    // @Mock 붙이면 가짜 리파지토리 생성
    @Mock
    private EmpRepository empRepository;

    // @InjectMocks : 위에서 만든 가짜 리파지토리를 사용해서 서비스(EmpService)를 쓸 수 있게 함
    @InjectMocks
    private EmpService empService;


    //    findAll() 테스트
    @DisplayName("findAll() : 서비스, 조회 함수")
    @Test
    void findAll() {
//        0. 가짜 데이터 넣기
        List<Emp> list = new ArrayList<>();

        list.add(Emp.builder()
                .eno(1111)
                .ename("홍길동")
                .job("THIEF")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );
        list.add(Emp.builder()
                .eno(22222)
                .ename("장길산")
                .job("TEACHER")
                .build()    // .build() : 마지막에 무조건 호출해야 객체가 생성됨
        );
//        1. given() : 기대값 설정  _given -> Alt + Insert (org.mockito) 선택
        given(empRepository.findAll()).willReturn(list);   // 리파지토리, findAll()함수 부르고, 리턴 기대값으로 list가 나올것

//        2. 테스트 실행
        List<Emp> list2 = empService.findAll();   // findAll() 테스트 결과를 list2 배열에 넣기

//        3. 결과 검증(검토) : assert()_구버전복잡, assertThat()_간단
        //           assertThat(테스트실행값).비교함수(기댓값) : 일치하면 테스트 통과, 불일치하면 실패
        assertThat(list2.get(0).getEname()).isEqualTo("홍길동");
        assertThat(list2.get(1).getEname()).isEqualTo("장길산");
    }


    //    findById() 테스트
    @DisplayName("findById() : 서비스, eno로 조회 함수")
    @Test
    void findById() {
//        1. 기댓값 설정
        Optional<Emp> optionalEmp = Optional.ofNullable(Emp.builder()
                .eno(10)
                .ename("홍길동")
                .job("THIEF")
                .build());  // .build() : 마지막에 무조건 호출해야 객체가 생성됨

        given(empRepository.findById(anyInt())).willReturn(optionalEmp);

//        2. 테스트 실행
        Optional<Emp> optionalEmp2 = empService.findById(anyInt());

//        3. 결과 검토/검증
        assertThat(optionalEmp2.get().getEname()).isEqualTo(optionalEmp.get().getEname());
        assertThat(optionalEmp2.get().getJob()).isEqualTo("THIEF");
    }


    //    save() 테스트
    @DisplayName("save() : 서비스, 부서정보 생성 함수")
    @Test
    void save() {
        // insert 필요하니까 가짜 객체 생성
//        1. 기대값 설정 : deptRepository 객체 이용
        Emp emp = Emp.builder()
                .eno(1111)
                .ename("SA")
                .build();

        // given 설정 : 가짜 데이터를 통해 결과 미리 예측
        given(empRepository.save(any()))
                .willReturn(emp);  // 위에 만들어놓은 가짜데이터를 리턴

//        2. 테스트 실행(서비스의 save()함수 실행)
        Emp emp2 = empService.save(emp);

//        3. 테스트 결과 점검/검토
//        assertThat(emp2.getEname()).isEqualTo(emp.getEname());
        assertThat(emp2.getEname()).isEqualTo("SA");
    }


    //    removeById() 테스트
    @DisplayName("removeById() : 서비스, 사원번호로 삭제 함수")
    @Test
    void removeById() {
//        1. given() : 가정, 전제, 기댓값 설정
        given(empRepository.existsById(anyInt())).willReturn(true);    // 리파지토리가 가짜니까 미리 값을 넣어야 실행할 수 있음

//        2. 테스트 실행
        boolean bSuccessed = empService.removeById(anyInt());  // 서비스함수 삭제 실행

//        3. 몇 번 실행되었는지 검토, true가 나오는지 검토
        verify(empRepository, times(1)).deleteById(anyInt());  // deptRepository의 deleteById 함수가 1번 실행된 거 맞니?
        assertThat(bSuccessed).isEqualTo(true);     //bSuccessed 테스트 결과가 true 맞으면 통과
    }


    //    removeAll() 테스트
    @DisplayName("removeAll() : 서비스, 모두 삭제 함수")
    @Test
    void removeAll() {
//        1. 테스트 실행
        empService.removeAll();

//        2. 위의 함수가 몇 번 실행되었는지 확인
        // verify(리파지토리객체, times(실행횟수)) : 함수 실헹 횟수 점검  .. times -> 자동임포트, Mockito.times 선택
        verify(empRepository, times(1)).deleteAll();
    }


    //    findAllByEnameContaining() 테스트
    @DisplayName("findAllByEnameContaining() : 서비스, 사원명으로 like 검색 함수")
    @Test
    void findAllByEnameContaining() {
//        1. 기댓값 설정 및 결과 예측치 정의_given()
        List<Emp> list = new ArrayList<>();

        list.add(Emp.builder().eno(10)
                .eno(8888)
                .ename("SAM")
                .job("TEACHER")
                .hiredate("1982-01-23 00:00:00")
                .salary(1800)
                .dno(10)
                .build()
        );
        list.add(Emp.builder()
                .eno(8889)
                .ename("홍길동")
                .job("THIEF")
                .hiredate("1982-01-01 00:00:00")
                .salary(2800)
                .dno(10)
                .build()
        );

        given(empRepository.findAllByEnameContaining(any())).willReturn(list);

//        2. 테스트 실행
        List<Emp> list2 = empService.findAllByEnameContaining(any());

//        3. 테스트 검증
        assertThat(list2.get(0).getEname()).isEqualTo("SAM");
        assertThat(list2.get(1).getEname()).isEqualTo("홍길동");

    }
}