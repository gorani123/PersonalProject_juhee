package com.example.simpledms.service;

import com.example.simpledms.model.Emp;
import com.example.simpledms.repository.EmpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


/**
 * packageName : com.example.jpaexam.service.exam01
 * fileName : EmpService
 * author : juhee
 * date : 2022-11-01
 * description : 부서 업무 서비스 클래스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Service : 자동으로 객체 만들어주는 어노테이션
@Service
public class EmpService {
    // 그전에는 DAO를 받았음. 그게 repository로 변경됨
    // 객체 생성
    @Autowired
    EmpRepository empRepository;  // JPA CRUD 함수가 있는 인터페이스 객체


    // 전체 조회 함수 : findAll() -> 변경) 페이징 처리
    // empRepository. (점) 하면 JPA의 기본함수들 불러서 쓸 수 있음
    public Page<Emp> findAll(Pageable pageable){
        Page<Emp> page = empRepository.findAll(pageable);

        return page;
    }


    // 사원 번호로 조회하는 함수 -----🤩
    // Optional 객체 : null 방지 객체
    // Optional 주요 함수 : .get() 안에 있는 객체 꺼내기 함수
    //                     .isPresent() 안에객체 있으면 true, 없으면 false
    public Optional<Emp> findById(int eno) {
        Optional<Emp> optionalEmp = empRepository.findById(eno);

        return optionalEmp;
    }


    // 사원 정보 저장/수정 함수 -----🤡 😨
    public Emp save(Emp emp) {
        Emp emp2 = empRepository.save(emp);
        return emp2;
    }

    // 수정하는 함수 -----😨
    // 위의 save 함수가 공용으로 처리


    // 사원번호(eno)로 삭제하는 함수 -------😤
    public boolean removeById(int eno) {
        // existsById(기본키) 있으면 삭제 실행 + true 리턴
        if (empRepository.existsById(eno) == true) {
            empRepository.deleteById(eno);
            return true;
        }
        // 없으면 그냥 false 리턴
        return false;
    }


    // 전체 삭제 함수 : removeAll()
    // empRepository 에 사용자함수 만들 필요 없이 JPA 기본함수 deleteAll() 사용하면 됨
    public void removeAll() {
        empRepository.deleteAll();
    }


    // 사원명(ename)으로 like 검색 : findAllByEnameContaining() -> 페이징 처리 추가-------🎃
    public Page<Emp> findAllByEnameContaining(String ename, Pageable pageable) {
        Page<Emp> page = empRepository.findAllByEnameContaining(ename, pageable);

        return page;
    }




}
