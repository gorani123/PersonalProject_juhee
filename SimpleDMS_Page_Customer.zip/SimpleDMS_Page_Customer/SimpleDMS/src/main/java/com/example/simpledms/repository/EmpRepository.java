package com.example.simpledms.repository;

import com.example.simpledms.model.Emp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : EmpRepository
 * author : juhee
 * date : 2022-11-01
 * description : EMP 리파지토리(==DAO) CRUD용 함수가 있는 인터페이스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Emp클래스의 기본키인 @ID 속성
@Repository
public interface EmpRepository extends JpaRepository<Emp, Integer> {
    // 🎃사원명(ename)으로 조회하는 like 검색 함수
    // 프엔, EmpDataService.js 에서 쿼리스트링 방식으로 url 보냈지만
    // 아래에서는 함수, 어떤 방식으로 정의하든 상관없음

    // 아래, 쿼리메소드 방식으로 함수 정의
    // 여러건 출력, findAllBy / 한건, findBy

    // 페이징 처리 추가
    Page<Emp> findAllByEnameContaining(String ename, Pageable pageable);


//리파지토리 -> 서비스 -> 컨트롤러

}
