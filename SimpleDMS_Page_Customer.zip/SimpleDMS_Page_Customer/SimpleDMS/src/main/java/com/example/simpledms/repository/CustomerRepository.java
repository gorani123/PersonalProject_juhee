package com.example.simpledms.repository;

import com.example.simpledms.model.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * packageName : com.example.simpledms.repository
 * fileName : CustomerRepository
 * author : juhee
 * date : 2022-11-08
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-08         juhee          최초 생성
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer > {

    // 🎃부서명(email)으로 조회하는 like 검색 함수
    // 프엔, DeptDataService.js 에서 쿼리스트링 방식으로 url 보냈지만
    // 아래에서는 함수, 어떤 방식으로 정의하든 상관없음
    // 쿼리스트링 방식 url : ?변수명=값&변수명2=값2...

    // 아래, 쿼리메소드 방식으로 함수 정의

    // 페이징 처리 추가 (Pageable)
    Page<Customer> findAllByEmailContaining(String email, Pageable pageable);
}
