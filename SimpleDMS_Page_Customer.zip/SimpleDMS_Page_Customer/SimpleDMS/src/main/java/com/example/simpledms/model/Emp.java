package com.example.simpledms.model;

import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;

/**
 * packageName : com.example.jpaexam.model
 * fileName : Emp
 * author : juhee
 * date : 2022-11-01
 * description : 사원 모델(==엔티티)
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// 😦 어노테이션 설명
// @Entity : 대상 클래스를 참고하여 DB에 물리 테이블을 생성함
// @Table(name = "테이블명") : 테이블 자동생성시, 테이블명(TB_EMP)으로 생성됨(테이블명 직접지정). 물론 컬럼명도 직접지정 가능
// @SequenceGenerator(각종 속성) : Oracle DB 시퀀스 생성 시 사용할 속성들
// @DynamicInsert : insert 할 때, null인 컬럼을 제외해서 sql문을 자동으로 생성
// @DynamicUpdate : update 할 때, null인 컬럼을 제외해서 sql문을 자동으로 생성
// @Id : 기본키가 지정될 속성 (DB에 기본키를 자동으로 만들어 줌)
// @Column(columnDefinistion = "컬럼타입(개수)") : DB에 자동생성될 테이블의 컬럼 정보를 직접 지정(안하면 자동, 엉망으로 만들어 줌)
@Entity
@Table(name="TB_EMP")      // 테이블명 ***
@SequenceGenerator(        //👀 아래 @GenerateValue()에서 써준거 세부적으로 써줘야 함
        name= "SQ_EMP_GENERATOR",
        sequenceName = "SQ_EMP",
        initialValue = 1,       // 초기값
        allocationSize = 1      // 증가값
)
@Getter // 롬북
@Setter // 롬북
@ToString // 롬북
@Builder  // 왜인지 모르지만 아래 @AllArgsConstructor와 같이 써야 빨간줄 안 뜸
@AllArgsConstructor
@NoArgsConstructor
// SQL문 자동생성시 null 컬럼데이터는 제외시키는 어노테이션: @DynamicInsert @DynamicUpdate
@DynamicInsert
@DynamicUpdate
// @Where(clause="DELETE_YN = 'N'") : 이 엔티티에 접근하는 모든 조회들(sql)은 이 조건(DELETE_YN='N')인 것만 검색
@Where(clause="DELETE_YN = 'N'")
// sofe delete : 삭제하는 척만 하기. 화면에서는 삭제한 것 처럼 데이터가 안 보이지만 db에서는 데이터를 삭제하지 않음
@SQLDelete(sql="UPDATE TB_EMP SET DELETE_YN = 'Y', DELETE_TIME = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') WHERE ENO = ?")
public class Emp extends BaseTimeEntity {
        // 속성
        // @Id : 기본키(PrimaryKey). not null. 유일해야 함 (하나는 필수. 없으면 클래스명(Detp)에 빨간줄 뜸)
        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_EMP_GENERATOR") //👀 시퀀스_기본키속성에 닮
        @Column(columnDefinition = "NUMBER")
        private Integer eno;

        @Column(columnDefinition = "VARCHAR2(255)")
        private String ename;

        @Column(columnDefinition = "VARCHAR2(255)")
        private String job;

        @Column(columnDefinition = "NUMBER")
        private Integer manager;

        @Column(columnDefinition = "VARCHAR2(255)")
        private String hiredate;

        @Column(columnDefinition = "NUMBER")
        private  Integer salary;

        @Column(columnDefinition = "NUMBER")
        private  Integer commission;

        @Column(columnDefinition = "NUMBER")
        private  Integer dno;


    }
