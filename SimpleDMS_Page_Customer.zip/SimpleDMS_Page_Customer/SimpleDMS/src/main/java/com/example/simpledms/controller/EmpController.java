package com.example.simpledms.controller;

import com.example.simpledms.model.Emp;
import com.example.simpledms.service.EmpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;


/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Emp07Controller
 * author : juhee
 * date : 2022-11-01
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중유
 * 요약 :
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url

//@CrossOrigin(허용할 사이트주소_Vue의 포트번호_8081_달라지니까체크하기👀) : CORS 보안을 해제시키는 어노테이션
//    CORS보안 : 기본적으로 한 사이트에서 한 포트만 사용가능한 기본 보안

    // 👀프엔 백엔 연동 URL : http://localhost:8081/emp 👀

@Slf4j
@CrossOrigin(origins = "http://localhost:8080") // 👀이렇게 요청이 오면 기본보안 해제해 주렴
//@CrossOrigin(origins = "http://localhost") // 11/07 포트번호 80으로 바꿈(포트번호생략가능)_nginx로 연동
// 11/7 오후, @CrossOrigin 대신 configration 폴더에 WebConfig 파일로 설정!!
@RestController
@RequestMapping("/api")
public class EmpController {

    @Autowired
    EmpService empService;


//    // 전체 조회 함수 : select -> 검색 -> GetMapping()
//    @GetMapping("/emp")
//    public ResponseEntity<Object> getEmpAll() { ... }

    // 검색어가 없으면 전체검색, 있으면 like 검색 ====> 위의 getEmpALl 변경!
    // 🎃사원명(ename)으로 like 검색 : select -> GetMapping()
    // 프엔, 쿼리스트링
    // findByDname(dname){
    //    return http.get(`/emp?dname=${dname}`);          --> 매개변수 ename
    // }
    //      프엔에서 파라미터({}사용) 매개변수 전송방식을 사용 -> 백엔, @PathVariable 로 매개변수 받음
    //      프엔에서 쿼리스트링(?사용) 매개변수 전송방식을 사용 -> 백엔, @RequestParam 으로 매개변수 받음

    // 백엔, @RequestParam -> 매개변수 없는 경우, 파라미터,쿼리스트링 다 받을 수 있음
    //      매개변수 없는 것(/emp) : GET http://localhost:8000/api/emp
    //      매개변수 있는 것(/emp?dname=SA) : GET http://localhost:8000/api/emp?dname=SA

    @GetMapping("/emp")
    public ResponseEntity<Object> getEmpAll(@RequestParam(required = false) String ename,
                                            @RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "#") int size
                                            ){

        try{
            // Pageable 객체 정의(page, size 값 설정)
            Pageable pageable = PageRequest.of(page, size);

            // Page 객체 정의
            Page<Emp> empPage;
//            List<Emp> list = Collections.emptyList();      // 초기화.. null 대신 기본함수, emptyList()에 넣어서 사용하라고

            // findALl() 함수 생략해도 전체검색 가능 -> like 검색시 사원명 매개변수가 **이더라도 전체검색 되니까
            //            if(ename == null) {  // ename이 null일 경우, 전체 검색
            //                list = empService.findAll();
            //            }
            //            else{         // ename에 값이 있을 경우, 부서명 like 검색
            //                list = empService.findAllByEnameContaining(ename);
            //            }

            // 페이징 처리되는 findAllBYDnameContaining() : dname에 값이 있을 경우, 부서명 like 검색
            empPage = empService.findAllByEnameContaining(ename, pageable);

            // 맵 자료구조에 넣어서 전송
            Map<String, Object> response = new HashMap<>();
            response.put("emp", empPage.getContent());
            response.put("currentPage", empPage.getNumber());
            response.put("totalItems", empPage.getTotalElements());
            response.put("totalPages", empPage.getTotalPages());


            // list배열이 비어있지 않으면 -> empPaged 가 비어있지 않으면
            if(empPage.isEmpty() == false) {
                //                           데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 🤩사원 번호로 조회하는 함수 : get -> 검색 -> @Getmapping
    @GetMapping("/emp/{eno}")
    public ResponseEntity<Object> getEmpId(@PathVariable int eno){

        try{
//            log.debug("eno : "+eno);
            Optional<Emp> optionaEmp = empService.findById(eno);

            // optional(null이 아니고), 데이터가 있으면(true)
            if(optionaEmp.isPresent() == true) {
                // 데이터 + 성공 메시지 전송
                log.debug("eno2 : "+eno);   // 여기까진 출력됨............

                // get함수로 안에 있는 데이터 조회
                return new ResponseEntity<>(optionaEmp.get(), HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 🤡새로운 사원 정보 저장요청 함수 : insert -> PostMapping()
    @PostMapping("/emp")
    public ResponseEntity<Object> createEmp(@RequestBody Emp emp) {

        try {
            Emp emp2 = empService.save(emp);

            return new ResponseEntity<>(emp2, HttpStatus.OK); // OK 메시지

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 😨새로운 사원 정보 수정요청 함수 : @PutMapping()
    // int는 @PathVariable, 객체는 @RequestBody로 받음(덩치가 커서)
    @PutMapping("/emp/{eno}")
    public ResponseEntity<Object> updateEmp(@PathVariable int eno,
                                             @RequestBody Emp emp) {
        try {
            Emp emp2 = empService.save(emp);

            return new ResponseEntity<>(emp2, HttpStatus.OK); // OK 메시지

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 😤사원 번호(eno)로 삭제하는 함수 : delete -> @DeleteMapping
    @DeleteMapping("/emp/deletion/{eno}")
    public ResponseEntity<Object> deleteEmp(@PathVariable int eno){
//        log.debug("eno2 : "+eno);

        try{
//            log.debug("eno : "+eno);
            boolean bSuccess = empService.removeById(eno);

            if(bSuccess == true) {
                log.debug("eno2 : "+eno);

                // 성공 메시지 OK 전송
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 전체 삭제 함수 : delete -> 검색 -> DeleteMapping()
    @DeleteMapping("/emp/all")
    public ResponseEntity<Object> removeAll() {

        try {
            empService.removeAll();
            return new ResponseEntity<>(HttpStatus.OK); // OK 메시지

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    


}

