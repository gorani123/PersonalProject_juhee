package com.example.simpledms.controller;

import com.example.simpledms.model.Customer;
import com.example.simpledms.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * packageName : com.example.simpledms.controller
 * fileName : CustomerController
 * author : juhee
 * date : 2022-11-08
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-11-08         juhee          최초 생성
 */
@Slf4j
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:8080")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    // 검색어가 없으면 전체검색, 있으면 like 검색
    // 🎃부서명(email)으로 like 검색 : select -> GetMapping()
    // 프엔, 쿼리스트링
    //      프엔에서 파라미터({}사용) 매개변수 전송방식을 사용 -> 백엔, @PathVariable 로 매개변수 받음
    //      프엔에서 쿼리스트링(?사용) 매개변수 전송방식을 사용 -> 백엔, @RequestParam 으로 매개변수 받음
    //      ---> GET http://localhost:8000/api/Customer?dname=SA
    // 백엔, @RequestParam -> 매개변수 없는 경우, 파라미터,쿼리스트링 다 받을 수 있음 (/Customer) (/Customer?dname=SA)
    // @RequestParam(required = false) : false 매개변수에 값이 없어도 에러가 발생하지않음(기본값은 required = true)
    // @RequestParam(defaultValue = "값") : 매개변수에 값이 없는 경우 기본값을 설정
    @GetMapping("/customer")
    public ResponseEntity<Object> getCustomerAll(@RequestParam(required = false) String email,
                                             @RequestParam(defaultValue = "0") int page,      // 디폴트값(검색안할시 0페이지)
                                             @RequestParam(defaultValue = "3") int size ){    // 디폴트값(검색안할시 3페이지씩표시)

        try{
            // Pageable 객체 정의 ( page, size 값 설정 )
            Pageable pageable = PageRequest.of(page, size);

            // Page 객체 정의
            Page<Customer> customerPage;

            // findAll()함수 생략해도 전체검색 됨 => Like 검색시 부서명 매개변수가 **이더라도 전체검색 되니까!!

            // 페이징 처리되는 findAllByEmailContaining() : dname에 값이 있을 경우, 부서명 like 검색
            customerPage = customerService.findAllByEmailContaining(email, pageable);

            // 맵 자료구조에 넣어서 전송
            Map<String, Object> response = new HashMap<>();
            response.put("customer", customerPage.getContent());
            response.put("currentPage", customerPage.getNumber());
            response.put("totalItems", customerPage.getTotalElements());
            response.put("totalPages", customerPage.getTotalPages());

            // list배열이 비어있지 않으면
            if(customerPage.isEmpty() == false) {
                //                           데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 🤡새로운 고객 정보 저장요청 함수 : insert -> @PostMapping()
    @PostMapping("/customer")
    public ResponseEntity<Object> createCustomer(@RequestBody Customer customer){

        try{
            Customer customer2 = customerService.save(customer);

            return new ResponseEntity<>(customer2, HttpStatus.OK); // OK 메시지

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 🤩cid로 조회하는 함수 : get -> @GetMapping
    @GetMapping("/customer/{cid}")
    public ResponseEntity<Object> getCustomerId(@PathVariable int cid){

        try{
//            log.debug("cid : "+cid);

            Optional<Customer> optionalCustomer = customerService.findById(cid);

            // optional(null이 아니고), 데이터가 있으면(true)
            if(optionalCustomer.isPresent() == true) {
                // 데이터 + 성공 메시지 전송
//                log.debug("dno2 : "+dno);
                // get함수로 안에 있는 데이터 조회
                return new ResponseEntity<>(optionalCustomer.get(), HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)

        }
    }

    // 😨새로운 고객 정보 수정요청 함수 : update -> @PutMapping()
    // int는 @PathVariable, 객체는 @RequestBody로 받음(덩치가 커서)
    @PutMapping("/customer/{cid}")
    public ResponseEntity<Object> updateCustomer(@PathVariable int cid,
                                             @RequestBody Customer customer) {

        try {
            Customer customer2 = customerService.save(customer);

            return new ResponseEntity<>(customer2, HttpStatus.OK); // OK 메시지

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


    // 😤cid로 삭제하는 함수 : delete -> @DeleteMapping
    @DeleteMapping("/customer/deletion/{cid}")
    public ResponseEntity<Object> deleteCustomer(@PathVariable int cid){

        try{
//                log.debug("cid2 : "+cid);
            boolean bSuccess = customerService.removeById(cid);

            if(bSuccess == true) {
//                log.debug("cid2 : "+cid);

                // 성공 메시지 OK 전송
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)

        }
    }






}
