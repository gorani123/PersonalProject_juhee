package com.example.jpacustomexam.model.exam04;

import com.example.jpacustomexam.model.BaseTimeEntity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

/**
 * packageName : com.example.jpacustomexam.model.exam04
 * fileName : Employee
 * author : juhee
 * date : 2022-10-27
 * description : 조인을 위한 사원 테이블 @ManyToOne (사원이 다, many - 부서가 1)
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
@Entity
@Table(name="TB_EMPLOYEE")      // 테이블명 ***
@SequenceGenerator(        //👀 아래 @GenerateValue()에서 써준거 세부적으로 써줘야 함
        name= "SQ_EMPLOYEE_GENERATOR",
        sequenceName = "SQ_EMPLOYEE",
        initialValue = 1,       // 초기값
        allocationSize = 1      // 증가값
)
@Getter
@Setter
@ToString
@Builder  // 왜인지 모르지만 아래 @AllArgsConstructor와 같이 써야 빨간줄 안 뜸
@AllArgsConstructor
@NoArgsConstructor
// SQL문 자동생성시 null 컬럼데이터는 제외시키는 어노테이션: @DynamicInsert @DynamicUpdate
@DynamicInsert
@DynamicUpdate
public class Employee extends BaseTimeEntity {
    // 속성
    // @Id : 기본키(PrimaryKey). not null. 유일해야 함 (하나는 필수. 없으면 클래스명(Detp)에 빨간줄 뜸)
    // @GenerateValue(..SEQUENCE, ...) :오라클은 시퀀스 사용함 (시퀀스 사용_ORACLE, POSTGRE 등/ increment 사용_MYSQL, MARIA DB 등)

    @Id     // @Id : 기본키
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_EMPLOYEE_GENERATOR") //👀 시퀀스_기본키속성에 닮
    @Column(columnDefinition = "NUMBER")
    private Integer eno;

    @Column(columnDefinition = "VARCHAR2(255)")
    private String ename;

    @Column(columnDefinition = "VARCHAR2(255)")
    private String job;

    @Column(columnDefinition = "NUMBER")
    private Integer manager;

    @Column(columnDefinition = "VARCHAR2(255)")
    private String hiredate;

    @Column(columnDefinition = "NUMBER")
    private Integer salary;

    @Column(columnDefinition = "NUMBER")
    private Integer commission;

    // 기존
//    @Column(columnDefinition = "NUMBER")
//    private Integer dno;
    // 😦사원이 many, 부서가 one
    // 사원과 부서 조인 -> 공통컬럼 dno 이용 (사원테이블, 부서번호dno만 있고 부서이름이 없음. 궁금해)
    // sql (equal join) : select d.*, e.eno, e.ename from tb_dept d, tb_emp e where d.dno = e.dno
    // @ManyToOne 관계설정하기 : 객체 통으로 가지고와서 관계설정
    // @ManyToOne, @JoinColumn(name="공통컬럼명")
    // -> JPA가 자동으로 sql문 생성 -> FK(외래키) 만들어 줌 (FK걸면 성능 안좋아지므로 사실 안거는 케이스가 더 많다...뭔말인지ㅋ)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="dno")
    @JsonBackReference
    private Department department;

    // 그냥 @ManyToOne 으로만 달면
    //  1). 성능 저하(N+1 쿼리 문제) 발생👀
    //     : 일반적으로 쿼리가 1개 실행되어야하는데 1개 sql문 실행하면, n개의 sql문이 추가로 실행 되어버림
    //       첫 번째 쿼리 이후 두번째 쿼리가 추가로 실행되면서 성능이 대폭 저하되는 문제
    //       1st + 2nd 조인해서 쿼리해야 성능 개선되지만 JPA 엔진이 해석을 못하는 문제(Eager)로 발생됨
    //  -> @ManyToOne(fetch = FetchType.LAZY) : 지연로딩(Lazy)으로 모드 변경해서 성능저하 방지
    //  -> dto 사용하면 됨..
    
    //  2). 잭슨 자동변환 에러👀
    //     : @ManyToOne 관계설정 시, (숫자_private integer dno -> 객체_ private Dept dept 로 바뀌면서)
    //       잭슨이 자동변환시켜버림. 여기서 변환 에러 발생
    //       스프링에서 (클래스) 객체를 json 데이터로 변환해서 클라이언트로 전송함(Rest API, @RestController)
    //       클래스 객체  -- 잭슨(Jackson)이 자동변환--> json 데이터(byte)로 전송 -> 클라이언트에서 json데이터 자바로 받아서 뿌림
    //  -> @JsonIgnore, @JsonBackReference 로 잭슨아 무시해~

    // N+1 쿼리 문제
    // 내장함수 findAl()을 실행한다고 가정하자.
    // jpa엔진, sql문 만듦( select count(*) from tb_dept / select * from tb_dept : 쿼리 2개 작성한다고 가정
    // jpa 엔진(컨텍스트)에서 #1 select count(*) from tb_dept   #2 select * from tb_dept 자바메모리에 자동 저장(생성),
    //                     실행방식 :    즉시로딩(Eager)      /        지연로딩(Lazy)
    //                              sql문 생성 즉시 실행        자바메모리에 sql문 여러개 모인 뒤 commit 시점에 db로 실행
    // @manyToOne 의 기본모드는 즉시로딩임.
    // 뒤에 추가 sql문이 있는데 바로 실행해버림. 어? 쿼리 또 있네 그래서 추가로 또 실행해버림.. 조인하면 되는데... => N+1 문제


    // PK(기본키)와 FK(외래키)
    // 학생테이블의 학과코드(PK)의 값에 학과테이블의 학과코드에 없는 값이 들어간다면
    // 잘못된 데이터가 들어가게 되고, 이러한 데이터를 부모를 잃어버렸다라고 합니다.
    //
    // 그러므로 학생테이블에 데이터를 저장 또는 수정시 학과코드 데이터는 학과테이블에 있는 학과코드가 맞는지를 확인해야 합니다.
    // 이것을 자동하여 주는 것이 FK입니다.
    //
    // 그래서 FK는 PK를 대상으로만 만들 수 있음
    // FK는 항상 PK를 참조하게 되는데, 만에 하나 FK가 유일인덱스가 아닌 데이터를 매번 조회하게 되면
    // 성능에 심각한 문제가 발생할 수 있으므로 기본적인 성능을 보장하기 위해 PK를 대상으로만 FK를 만들수 있다
    //
    // 그러므로 PK와 FK를 이용하면 성능도 고려하면서 데이터 무결성도 보장을 할 수 있다
}
