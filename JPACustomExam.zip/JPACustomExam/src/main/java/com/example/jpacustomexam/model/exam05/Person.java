package com.example.jpacustomexam.model.exam05;

import javax.persistence.*;
import lombok.*;
import com.example.jpacustomexam.model.BaseTimeEntity;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
/**
 * packageName : com.example.jpacustomexam.model.exam05
 * fileName : Person
 * author : Moon
 * date : 2022-10-27-027
 * description : @OneToOne 관계 설정을 위한 클래스
 *                  한사람당 핸드폰 1개
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27-027         Moon          최초 생성
 */
@Entity
@Table(name = "TB_PERSON")
@SequenceGenerator(
        name= "SQ_PERSON_GENERATOR"
        , sequenceName = "SQ_PERSON"
        , initialValue = 1
        , allocationSize = 1
)
@Setter
@Getter
@ToString(exclude = "phone")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamicUpdate
@DynamicInsert
public class Person extends BaseTimeEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_PERSON_GENERATOR")
    private Integer no;
    @Column(columnDefinition = "VARCHAR2(255)")
    private String name;
    @Column(columnDefinition = "VARCHAR2(255)")
    private String job;

    // @OneToOne
    @OneToOne(mappedBy = "person")
    @JsonManagedReference
    private Phone phone;
}
