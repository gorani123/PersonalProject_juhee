package com.example.jpacustomexam.configuration;

import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * packageName : com.example.jpacustomexam.configuration
 * fileName : QuerydslConfig
 * author : juhee
 * date : 2022-10-27
 * description : Querydsl 을 위한 설정파일
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
//@Configuration : 스프링부트의 설정파일 용도로 사용하도록 만들어 주는 어노테이션. (자바 클래스가 .properties 파일과 같은 설정파일이 됨)
@Configuration
public class QuerydslConfig {

    // JPA 영속성 컨텍스트(관리공간)
    @PersistenceContext
    private EntityManager entityManager;

    // @Bean : @Service, @Repository, @Component 처럼 서버가 로딩되면 객체로 생성됨
    @Bean
    public JPAQueryFactory jpaQueryFactory(){
        return new JPAQueryFactory(entityManager);
    }

}
