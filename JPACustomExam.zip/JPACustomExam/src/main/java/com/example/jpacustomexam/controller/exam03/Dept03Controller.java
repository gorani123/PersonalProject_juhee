package com.example.jpacustomexam.controller.exam03;

import com.example.jpacustomexam.dto.DeptGroupDto;
import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.service.exam03.Dept03Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Dept07Controller
 * author : juhee
 * date : 2022-10-21
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중요
 * 요약 : 😦
 *      사용자 정의(custom) 함수 _ Repository에 작성
 *   1. 쿼리 메소드 : 자동으로 사용자정의 sql 문을 작성하기 위해 사용
 *      목적 : 기본 함수보다 다양한 sql문을 작성하기 위해 사용
 *      사용법 : 함수이름으로 sql 문장을 작성함 ( Repository 안에 함수명만 작성 )
 *      ex) JPA 클래스 === 대상 테이클
 *      ex) find == select
 *      ex) all = *
 *      ex) by == from
 *      ex) 속성 = where 컬럼
 *      ex) orderBy == order by
 *      ex) 속성 desc = 컬럼 desc
 *
 *   2. @Query(쿼리문)함수명() : 쿼리문에 해당되는 부분을 직접 개발자가 작성(sql문)
 *      쿼리문의 매개변수 전달 ->👀 :변수   => 함수명(@Param("변수") String 변수
 *      select * from tb_dept where dno = :변수명
 *      List<Dept> selectAll(@Param(변수명) 타입 변수명
 *
 *       2-1) nativeQuery = true : 일반 sql 문으로 작성
 *       2-2) nativeQuery = false, 생략 : 객체 쿼리
 *                                      ( 테이블명, 컬럼명 대신 클래스명, 속성(필드명) 사용 )
 *
 *   3. 페이징 처리 함수
 *      목적 : 전체 데이터를 화면에 출력하면 성능과 가독성이 떨어지므로, 몇 건씩 끊어서 보여주는 것
 *      페이징 객체 :
 *          1) 매개변수 페이징 객체 : Pageable
 *          2) 리턴될 페이징 객체 : Page<객체자료형>
 *      속성 : page = 현재페이지(0부터 시작) , size = 한 페이지에 보여 줄 데이터 수 (url 매개변수로 전달됨)
 *      클라이언트로 전송 할 데이터 : Map 자료구조 이용
 *          1) 데이터: 부서, 사원 등
 *          2) currentPage : 현재 페이지 수(정보) (총 10페이지 중 현재 3페이지에 위치)
 *          3) totalItem : 전체 데이터 수
 *          4) totalPages : 전체 페이지 수
 *
 *  조인, 동적쿼리
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam03")
public class Dept03Controller {

//     스프링부트가 가동될 때 자동생성된 서비스 객체를 @AUtowired 로 받아오기(new 연산자로 직접 생성하는 대신)
//     DI(의존성 주입_위와 같은 말) (@Ajutowired)
    @Autowired
    Dept03Service deptService;

    // URL 속성 : page _현재페이지 번호 size_ 한 페이지당 보여질 데이터 건수 (page=0 :첫번째페이지, 현재페이지). 기본 내림차순임
    //                                                                 page=1 : 두번째 페이지
    // URL : http://localhost:8000/exam03/dept/desc/paging?page=0&size=2
    // 쿼리스트링방식으로 받음 : ? 뒤의 값이 pageable로 쏙 들어옴
    @GetMapping("/dept/desc/paging")
    public ResponseEntity<Object> getDeptAll(Pageable pageable){

        try{
            // 리턴값 Page
            Page<Dept> page = deptService.findAllByOrderByDnoDesc(pageable);

            // 추가속성 Map 자료구조에 담아서 전송(클라이언트에게)
            // 웹 페이지 속성정보임(현재페이지, 다음페이지..
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 연습문제 1 : getDeptAllPage 첫 번째 작성법
    // URL 테스트 : http://localhost:8000/exam03/dept/all/paging?page=0&size=2
    // 정렬(sort) :  http://localhost:8000/exam03/dept/all/paging?page=0&size=2&sort=dno,desc
    @GetMapping("/dept/all/paging")
    public ResponseEntity<Object> getDeptAllPage(Pageable pageable){

        try{
            // 리턴값 Page
            Page<Dept> page = deptService.getDeptAllPage(pageable);

            // 추가속성 Map 자료구조에 담아서 전송(클라이언트에게)
            // 웹 페이지 속성정보임(현재페이지, 다음페이지..ㄴ
            // 페이지 정보를 앱 자료구조에 저장해서 전송
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 연습문제 2
    // URL 테스트 :  http://localhost:8000/exam03/dept/all/paging?page=0&size=2&sort=dno,desc
    // GET http://localhost:8000/exam03/dept/dname/S/paging?page=0&size=2
    //                                                      page=0 첫번째 페이지(현재페이지)
    // GET http://localhost:8000/exam03/dept/dname/S/paging?page=1&size=2
    //                                                      page=1 두번째 페이지
    @GetMapping("/dept/dname/{dname}/paging")
    public ResponseEntity<Object> findAllByDnameContaining(@PathVariable String dname,
                                                           Pageable pageable){

        try{
            // 리턴값 Page
            Page<Dept> page = deptService.findAllByDnameContaining(dname, pageable);

            // 추가속성 Map 자료구조에 담아서 전송(클라이언트에게)
            // 웹 페이지 속성정보임(현재페이지, 다음페이지..ㄴ
            // 페이지 정보를 앱 자료구조에 저장해서 전송
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

/////////////////////////////////////////////////////////////////////////////////
//    어노테이션 @Query 를 이용한 페이징 처리 (@Query  -> 페이징처리)
/////////////////////////////////////////////////////////////////////////////////
    // @Query 이용 페이징 처리 함수
    // 예제 1 : dname, loc로 like 검색을 하고, dname으로 정렬한 데이터를 페이징하세요
    @GetMapping("/dept/dname/{dname}/loc/{loc}/paging")
    public ResponseEntity<Object> selectByDnameAndLocPage(@PathVariable String dname,
                                                           @PathVariable String loc,
                                                           Pageable pageable){

        try{
            // 리턴값 Page
            Page<Dept> page = deptService.selectByDnameAndLocPage(dname, loc, pageable);

            // 추가속성 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 참고 /////////
    // 연습문제 1 수정 : getDeptAllPage 두번째 작성 방법 (컨트롤러만 변경함)
    // URL 테스트 : http://localhost:8000/exam03/dept/all/paging?page=0&size=2&sort=dno,desc
    // 서버 입장에서는 편하지만, 클라이언트 입장에서는 쿼리스트링방식(?page=0&size=2&...) 귀찮
    // ? 안쓰고 {}로 넘기는 파라미터 방식 (pageable 안쓰고 pathvariable)
    @GetMapping("/dept/all/paging2/page/{page}/size/{size}")
    public ResponseEntity<Object> getDeptAllPage2(@PathVariable int page,
                                                  @PathVariable int size){

        try{
            // 설정한 페이지(페이지 변수 page, size)를 Pageable 객체에 (초기화해서) 저장👀
            Pageable pageable = PageRequest.of(page, size);

            Page<Dept> deptPage = deptService.getDeptAllPage(pageable);

            // 페이지 정보(추가속성) Map 자료구조에 담아서 전송(클라이언트에게)
            // 로직 추가 : data +
            Map<String, Object> response = new HashMap<>();
            response.put("dept", deptPage.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", deptPage.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", deptPage.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", deptPage.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(deptPage.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 예제 3 : @Query 작성
    //    URL 테스트 : http://localhost:8000/exam03/dept/all/paging?page=0&size=2&sort=dno,desc
    @GetMapping("/dept/custom/paging")
    public ResponseEntity<Object> getDeptCustomDeptPage(Pageable pageable) {

        try {
            Page<DeptGroupDto> page = deptService.selectByCustomDeptPage(pageable);

//            페이지 정보를 맵 자료구조에 저장해서 전송
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());
            response.put("currentPage", page.getNumber());
            response.put("totalItems", page.getTotalElements());
            response.put("totalPages", page.getTotalPages());

            if (page.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 예제 4 : @Query 작성
    //    URL 테스트 : http://localhost:8000/exam03/dept/all/paging?page=0&size=2&sort=dno,desc
    @GetMapping("/dept/case/paging")
    public ResponseEntity<Object> selectByCase(Pageable pageable) {

        try {
            Page<DeptGroupDto> page = deptService.selectByCasePage(pageable);

//            페이지 정보를 맵 자료구조에 저장해서 전송
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());
            response.put("currentPage", page.getNumber());
            response.put("totalItems", page.getTotalElements());
            response.put("totalPages", page.getTotalPages());

            if (page.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



}



