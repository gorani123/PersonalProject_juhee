package com.example.jpacustomexam.controller.exam01;

import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.service.exam01.DeptService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Dept07Controller
 * author : juhee
 * date : 2022-10-21
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중유
 * 요약 :
 *      쿼리 메소드 : 자동으로 사용자정의 sql 문을 작성하기 위해 사용
 *      목적 : 기본 함수보다 다양한 sql문을 작성하기 위해 사용
 *      사용법 : 함수이름으로 sql 문장을 작성함 ( Repository 안에 함수명만 작성 )
 *      ex) JPA 클래스 === 대상 테이클
 *      ex) find == select
 *      ex) all = *
 *      ex) by == from
 *      ex) 속성 = where 컬럼
 *      ex) orderBy == order by
 *      ex) 속성 desc = 컬럼 desc
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam01")
public class DeptController {

    // 스프링부트가 가동될 때 자동생성된 서비스 객체를 @AUtowired 로 받아오기(new 연산자로 직접 생성하는 대신)
    // DI(의존성 주입_위와 같은 말) (@Ajutowired)
    @Autowired
    DeptService deptService;


    // 전체 조회 함수 : select -> 검색 -> GetMapping()
    // Select ->  @GetMapping      C reate  (get방식, 웹브라우저)
    // 👀 클라이언트가 (form태그) Get방식 (url, 웹브라우저) 보내면
    //              -> 서버 : @GetMapping("url")어노테이션으로  url로 받고 -> 내부 DB 에서 Select 요청
    @GetMapping("/dept")
    public ResponseEntity<Object> getDeptAll(){

        try{
            List<Dept> list = deptService.findAll();

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)

        }
    }

    // ID로 조회하는 함수 (select)
    // select -> 검색 -> GetMapping()
    // 👀 클라이언트가 (form태그) Get방식 (url, 웹브라우저) 보내면
    //              -> 서버 : @GetMapping("url")어노테이션으로  url로 받고 -> 내부 DB 에서 Select 요청
    // @pathVariable : 변수 하나를 받는 어노테이션
    // @ ㅇㅇㅇ       : 객체를 변수로 받는 어노테이션
    @GetMapping("/dept/{dno}")
    public ResponseEntity<Object> getDeptId(@PathVariable int dno){

        try {
            Optional<Dept> optionalDept = deptService.findById(dno);    // select 문

            if (optionalDept.isPresent() == true) {
//                데이터 + 성공 메세지 전송
//                옵셔널객체.get() : 안에 있는 객체 꺼내기 함수
                return new ResponseEntity<>(optionalDept.get(), HttpStatus.OK);
            } else {
//                데이터 없음 메세지 전송(클라이언트)
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // 204
            }

        } catch (Exception e) {
            log.debug(e.getMessage());
            // 서버에러 발생 메세지 전송(클라이언트)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 부서 정보를 추가하는 함수 (insert)
    // 👀 클라이언트가 (form태그) Post방식 (url, 웹브라우저) 보내면
    //              -> 서버 : @PostMapping("url")어노테이션으로 url로 받고 -> 내부 DB 에서 insert 요청
    //@RequestBody : 클라이언트에서 json객체를 전송하면 스프링부트 함수에서 매개변수로 전달받음
    @PostMapping("/dept")
    public ResponseEntity<Object> createDept(@RequestBody Dept dept) {

        try {
            Dept dept2 = deptService.save(dept); // insert 문 호출

            return new ResponseEntity<>(dept2, HttpStatus.OK);

        } catch (Exception e) {
            log.debug(e.getMessage());
            // 서버에러 발생 메세지 전송(클라이언트)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 수정 실행 함수 (update)
    // 👀 클라이언트가 (form태그) Put방식 (url, 웹브라우저) 보내면
    //              -> 서버 : @PutMapping("url")어노테이션으로 url로 받고 -> 내부 DB 에서 update 요청
    // 리턴을 ResponseEntity로! (로그메시지 받아야하니까)
    // 매개변수 두개 받아야해서 @PathVariable, @RequestBody
    @PutMapping("/dept/edit/{dno}")
    public ResponseEntity<Object> updateDept(@PathVariable int dno, @RequestBody Dept dept ){

        try {
            // 매개변수 dept안에 부서번호(기본키값) 있음 -> update 문 실행(save함수 호출)
            // 매개변수 dept안에 부서번호(기본키값) 없음 -> insert 문 실행(save함수 호출)
            Dept dept2 = deptService.save(dept); // update 문 실행

            return new ResponseEntity<>(dept2, HttpStatus.OK);

        } catch (Exception e) {
            log.debug(e.getMessage());
            // 서버에러 발생 메세지 전송(클라이언트)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 컨트롤러 삭제 함수
    // 👀 클라이언트가 (form태그) Delete방식 (url, 웹브라우저) 보내면
    //              -> 서버 : @deleteMapping("url")어노테이션으로 url로 받고 -> 내부 DB 에서 delete 요청, 실행 됨
    @DeleteMapping("/dept/delete/{dno}")
    public ResponseEntity<Object> deleteDept(@PathVariable int dno){

        try {
            // id에 해당하는 부서정보를 삭제하는 함수(removeById) 호출
            boolean bSueecss = deptService.removeById(dno); // delete 문 실행

            if(bSueecss == true) {
                // 성공메시지 전송
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                // 실패했을 경우 : id값 존재 안 함
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            log.debug(e.getMessage());
            // 서버에러 발생 메세지 전송(클라이언트)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



//    쿼리 메소드 연습 예제 (컨트롤러) /////////////////////////////////////////////////////////
    @GetMapping("/dept/desc")
    public ResponseEntity<Object> getDeptAllDesc() {

        try {
            List<Dept> list = deptService.findAllDesc();    // 전체 조회(내림차순)

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 1
    @GetMapping("/dept/descname")
    public ResponseEntity<Object> getDeptAllDesc2() {

        try {
            List<Dept> list = deptService.findAllDnameDesc();    // 전체 dname으로 내림차순 조회

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 2
    @GetMapping("/dept/desc/{dname}")
    public ResponseEntity<Object> getDeptAllDesc3(@PathVariable String dname)  {

        try {
            List<Dept> list = deptService.findAllLikeDname(dname);    // 전체 조회 like dname으로 내림차순 (dname 대문자로 써야함)

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    
    // 연습문제 3 
    @GetMapping("/dept/asc")    // url 중복되면 안 됨
    public ResponseEntity<Object> getDeptAllAsc() {

        try {
            List<Dept> list = deptService.findAllAsc();    // 전체 조회(내림차순)

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }
    



}



