package com.example.jpacustomexam.dto.querydsl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.criteria.CriteriaBuilder;

/**
 * packageName : com.example.jpacustomexam.dto.querydsl
 * <p>
 * fileName : EmpGroupQDto
 * <p>
 * author : ds
 * <p>
 * date : 2022-10-28
 * <p>
 * description :
 * <p>
 * ===========================================================
 * <p>
 * DATE            AUTHOR             NOTE
 * <p>
 * —————————————————————————————
 * <p>
 * 2022-10-28         ds          최초 생성
 */

// 롬북 !!!!!!!!!!!!!!!!!!!!!!!!!
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmpGroupQDto {
    // 문제 3 : 사원테이블의 급여 (count, sum, avg, max, min) 값을 입력하세요
    // 속성 (DTO 클래스에서는 속성만 정의)
    Long countVar;  // querydsl 에서 Long 자료형을 사용함 _count() 함수 일 경우
    Integer sumVar;
    Double avgVar;
    Integer maxVar;
    Integer minVar;

    // Dept07RepositoryCustomImpl 클래스의 querydslByGroupfunc()함수에서 쿼리dsl 사용해서 select할 때 속성 순서 맞춰야 함!!!


    // 10/28 만드는 순서*****  (별다섯개로 검색)
// model(exam04폴더의 Department) ->  Dept07Repository
// -> Dept07RepositoryCustom -> (QuerydslConfig) ->  Dept07RepositoryCustomImpl  --> DeptGroupQDto(가공데이터 출력하려고 만듦) --> Dept07RepositoryCustomImpl
// -> Dept07Service(07리파지토리 함수 받아서 정의)  -> Dept07Controller(07서비스의 함수 불러와서 실행)


////////////// 10/31
    // 실행중인 창(탭) 전환(Alt + tab) : Ctrl + tab
    // 클래스/함수 찾아가기 : ctrl + b

    // 문제 6 : dno, job 별 월 급여 합계
    Integer dno;
    String job;
    Integer sumSalary;

}
