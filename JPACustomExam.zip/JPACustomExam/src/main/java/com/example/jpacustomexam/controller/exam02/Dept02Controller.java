package com.example.jpacustomexam.controller.exam02;

import com.example.jpacustomexam.dto.DeptGroupDto;
import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.service.exam02.Dept02Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Dept07Controller
 * author : juhee
 * date : 2022-10-21
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중요
 * 요약 : 😦
 *      사용자 정의(custom) 함수 _ Repository에 작성
 *   1. 쿼리 메소드 : 자동으로 사용자정의 sql 문을 작성하기 위해 사용
 *      목적 : 기본 함수보다 다양한 sql문을 작성하기 위해 사용
 *      사용법 : 함수이름으로 sql 문장을 작성함 ( Repository 안에 함수명만 작성 )
 *      ex) JPA 클래스 === 대상 테이클
 *      ex) find == select
 *      ex) all = *
 *      ex) by == from
 *      ex) 속성 = where 컬럼
 *      ex) orderBy == order by
 *      ex) 속성 desc = 컬럼 desc
 *
 *   2. @Query(쿼리문)함수명() : 쿼리문에 해당되는 부분을 직접 개발자가 작성(sql문)
 *      쿼리문의 매개변수 전달 ->👀 :변수   => 함수명(@Param("변수") String 변수
 *      select * from tb_dept where dno = :변수명
 *      List<Dept> selectAll(@Param(변수명) 타입 변수명
 *
 *       2-1) nativeQuery = true : 일반 sql 문으로 작성
 *       2-2) nativeQuery = false, 생략 : 객체 쿼리
 *                                      ( 테이블명, 컬럼명 대신 클래스명, 속성(필드명) 사용 )
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam01")
public class Dept02Controller {

    // 스프링부트가 가동될 때 자동생성된 서비스 객체를 @AUtowired 로 받아오기(new 연산자로 직접 생성하는 대신)
    // DI(의존성 주입_위와 같은 말) (@Ajutowired)
    @Autowired
    Dept02Service deptService;

    // 전체 조회 함수 : select -> 검색 -> GetMapping()
    @GetMapping("/dept/dname/{dname}")
    public ResponseEntity<Object> getDeptAll(@PathVariable String dname){

        try{
            List<Dept> list = deptService.selectByDname(dname);

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 예제 2
    @GetMapping("/dept/dname/{dname}/loc/{loc}")
    public ResponseEntity<Object> getByDnameAndLoc(@PathVariable String dname,
                                                 @PathVariable String loc){

        try{
            List<Dept> list = deptService.selectByDnameAndLoc(dname, loc);

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


   // 예제 3
    @GetMapping("/dept/groupfunc")
    public ResponseEntity<Object> getByGroupFunc(){

        try{
            List<DeptGroupDto> list = deptService.selectByGroupFunc();

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 예제 4
    @GetMapping("/dept/Custom")
    public ResponseEntity<Object> selectByCustomDept(){

        try{
            List<DeptGroupDto> list = deptService.selectByCustomDept();

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 예제 5
    @GetMapping("/dept/Basicfunc")
    public ResponseEntity<Object> selectByBasicFunc(){

        try{
            List<DeptGroupDto> list = deptService.selectByBasicFunc();

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 예제 6
    @GetMapping("/dept/casewhen")
    public ResponseEntity<Object> selectByCase(){

        try{
            List<DeptGroupDto> list = deptService.selectByCase();

            // list배열이 비어있지 않으면
            if(list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }




}



