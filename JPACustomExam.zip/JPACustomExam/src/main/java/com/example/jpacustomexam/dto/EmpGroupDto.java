package com.example.jpacustomexam.dto;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.dto
 * fileName : DeptGroupDto
 * author : juhee
 * date : 2022-10-24
 * description :  group by 결과를 저장할 DTO 인터페이스
 * (모델에 저장할 속성이 마땅치 않거나 없는 속성, 몇 개만 뽑아서 만들고싶을 때 dto에 만듦)
 * 쿼리메소드 에서 그룹함수를 지원하지 않으므로, 담을 그릇(클래스)로 (모델_(Dept 객체)  과 유사한) DTO 클래스 생성
 *  DTO : Data Transfer Object 내부 전송용 클래스. 가공된 추가 데이터를 담을 클래스
 * nativeQuery를 사용할 경우, DTO 를 인터페이스로 만듦(안에 getter만 정의)_ 프로젝션이라고 함
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
public interface EmpGroupDto {

    // 연습문제 5
    // 결과값 저장할 함수 : getter 함수 형태로 만듦
    // dno, job, dno/job별 salary합계
    Integer getDno();
    String getJob();
    Integer getSumSalary();

    // 연습문제 6
    Integer getAvgSalary();

    // 연습문제 7
    Integer getMaxSalary();

    // 연습문제 9
    Integer getcountEno();

    // 연습문제 10
    String getMaxHiredate();
    String getMinHiredate();



}
