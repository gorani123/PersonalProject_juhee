package com.example.jpacustomexam.repository;

import com.example.jpacustomexam.dto.EmpGroupDto;
import com.example.jpacustomexam.model.Emp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * packageName : com.example.jpaexam.repository
 * fileName : EmpRepository
 * author : juhee
 * date : 2022-10-20
 * description : EMP 리파지토리(==DAO) CRUD용 함수가 있는 인터페이스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Emp클래스의 기본키인 @ID 속성
@Repository
public interface EmpRepository extends JpaRepository<Emp, Integer> {
    // JPAl 함수를 사용할 수 있음(jpql)_응용
    // @Query , 쿼리메소드 (쿼리 직접 작성_sql문)
//     1. 쿼리 메소드 방식
// 전체조회 후 내림차순 정렬 : findAllByOrderByDnoDesc() 함수 이름 분석
// find + All + By + OrderBy + Dno + Desc
// find : 데이터 찾기 (-> select)
// All : 여러 건(배열) (-> * )
// By : 고정(항상 나옴)  (-> from )
// 컬럼명(클래스_모델_속성명) : 생략 (있으면 매개변수로 함수명()안에 들어옴)  (where 절의 컬럼명_조건절)
// OrderBy : 정렬 (고정) (-> order by )
// 속성명Desc : 속성명을 기준으로 내림차순 정렬 (-> 컬럼명 desc)
// 속성명Asc : 속성명을 기준으로 오름차순 정렬 (-> 컬럼명 asc)

//    쿼리 메소드 연습문제
//    1. eno 속성(컬럼)에 대해서 내림차순으로 전체 조회
    List<Emp> findAllByOrderByEnoDesc();   // 전체조회를 내림차순으로 하는 함수 -> 이것을 사용하는 규칙


//    2. ename like 검색하여 ename으로 내림차순 조회
//    select * from emp where ename like '%매개변수%' order by ename;
    // findAllBy + 조건절 
    List<Emp> findAllByEnameContainingOrderByEnameDesc(String ename);


//    3. emp 테이블에서 job에 like 검색을 추가하고, job 내림차순으로 정렬하는 함수
//    select * from tb_Emp where job like '%%' order by job desc;
//    like-> Containing 사용👀
    List<Emp> findAllByJobContainingOrderByJobDesc(String job);


//    4. emp 테이블에서 job이 manager이고, 매개변수로 부서번호(dno)를 전달받는 함수
//    select * from tb_emp where job = 'manager' and dno = 20;
//    매개변수 2개(job, dno)👀
    List<Emp> findAllByJobAndDno(String job, int dno);


//    5. emp 테이블에서 salary가 1000~1500 사이의 값을 갖는 사원을 조회하는 함수 (Ename으로 정렬)
//    select * from tb_emp where salary between 1000 and 1500;
//    between 사용
    List<Emp> findAllBySalaryBetweenOrderByEname(int first, int last);


//    6. emp 테이블에서 job을 매개변수로 받는 함수 (단, job의 매개변수 값은 대문자 또는 소문자 모두 가능)
//    select * from tb_emp where job = upper('manager');
//    ignorecase 사용
    List<Emp> findAllByJobIgnoreCase(String job);


//    7. commission 을 받을 수 있는 자격이 되는 사원을 모두 출력하는 함수
//    select * from tb_emp where commission is not null;
    List<Emp> findAllByCommissionIsNotNull();
    // findAllByCommissionNotNull() 도 가능


//    8. 급여(salary)는 내림차순, 사원명(ename)은 오름차순으로 정렬하는 함수
//    select * from tb_emp order by salary desc, ename asc;
    List<Emp> findAllByOrderBySalaryDescEnameAsc();


//    9. salary < 1000 또는 salary > 1500 조건을 만족하는 사원을 출력하는 함수
//    select * from tb_emp where (salary <1000 || salary >1500)
//    select * from th_emp where salary < 1000 or salary > 1500
    List<Emp> findAllBySalaryLessThanOrSalaryGreaterThan(int first, int second);

////    select * from th_emp where salary not between 1000 and 1500 *********
//    List<Emp> findAllBySalaryBetween(int first, int second);

//    10. commission이 300이거나, 500이거나, 1500인 사원을 출력하는 함수
//    select * from tb_emp where commission in(300, 500, 1500);
    List<Emp> findAllByCommissionIsOrCommissionOrCommission(int first, int second, int last);


///////////////////////////////////////////////////////////////////////////////////////////////////////////
//    exam02 : @Query
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//    연습문제 1
//    ename like 검색 함수를 작성(정의)하세요
//    단, @query 사용, native 쿼리로 작성
    // like검색: Containing
    // sql : select * from tb_dept where ename like '%S%'
    @Query(value = "select e.* from tb_emp e where e.ename like %:ename%" , nativeQuery = true)
    List<Emp> selecByEname(@Param("ename") String ename);
    // 쿼리문 :뒤에 붙은게 매개변수임. :ename -> @Param("ename") 으로 받으면 됨
    //  :변수명 -> 함수명(@Param("변수") String 변수)👀


//    연습문제 2
//    salary 내림차순, ename 오름차순으로 정렬하는 함수 작성
//    단, @query 사용, native 쿼리로 작성
    // select * from tb_emp order by salary desc, ename asc;
    @Query(value = "select e.* from tb_emp e " +
            "order by e.salary desc, e.ename asc" , nativeQuery = true)
    List<Emp> selectDescAsc();


//    연습문제 3
//    commission 이 null 이고, salary 가 매개변수값보다 같거나 큰 사원 정보를 출력하세요
//    단, @query 사용, native 쿼리로 작성
    // select e.* from tb_emp e where commission is null and (salary >= 3000);
    @Query(value = "select e.* from tb_emp e " +
            "where commission is null and (salary >= :salary) " , nativeQuery = true)
    List<Emp> selectSalary(@Param("salary") int salary);
    // 쿼리문 :뒤에 붙은게 매개변수임. :salary -> @Param("salary") 으로 받으면 됨
    //  :변수명 -> 함수명(@Param("변수") String 변수)👀


//    연습문제 4
//    1982년도에 입사한 사원을 출력하는 함수를 정의하세요
//    단, 입사일(hiredate)은 내림차순 정렬
    @Query(value = "select e.* " +
            "from tb_emp e " +
            "where hiredate between :first and :last " +
            "order by hiredate desc" , nativeQuery = true)
    List<Emp> selectHiredate(@Param("first") String first,
                             @Param("last") String last);

//    연습문제 5
//    부서별(dno), 직위별(job) 월 급여 합계(sum)를 출력하는 함수 정의
//    단 dto 만들어서 사용(group by, sum함수는 모델에 담을 수 없음)
//    group by sum 오라클 검색
//    @Query(value = "select job, dno sum(sal) from emp group by job, dno" , nativeQuery = true)
//    List<EmpGroupDto> selectSum();
    @Query(value = "select e.dno, e.job, sum(e.salary) as SumSalary " +
            "from tb_emp e " +
            "group by e.dno, e.job", nativeQuery = true)
    List<EmpGroupDto> selectGroupDnoJob();
    // EmpGroupDto의 getter함수(dno, job, sumsalary)에 담아서 출력


//    연습문제 6
//    부서별 평균 월급여를 출력하는 함수를 정의하세요. (소숫점단위는 절삭)
    // select dno, trunc(avg(salary)) from tb_emp group by dno;
    @Query(value = "select e.dno, trunc(avg(e.salary)) as AvgSalary " +
            "from tb_emp e " +
            "group by e.dno", nativeQuery = true)
    List<EmpGroupDto> selectGroupDnoTrunc();


//    연습문제 7
//    부서별 최고급여 중에서 3000 이상인 사원만 조회하는 함수를 정의하세요
    //select dno, max(salary) from tb_emp where salary>= 3000 group by dno;
    //select dno, max(salary) as Maxsalary from tb_emp group by dno having max(salary) >= 3000;

//    @Query(value = "select e.dno, max(e.salary) as MaxSalary " +
//            "from tb_emp e " +
//            "where e.salary>= 3000 " +
//            "group by e.dno", nativeQuery = true)

//    @Query(value = "select dno, max(salary) as Maxsalary " +
//            "from tb_emp " +
//            "group by dno " +
//            "having max(salary) >= 3000", nativeQuery = true)
//    List<EmpGroupDto> selectGroupMax();

    @Query(value = "select dno, max(salary) as Maxsalary " +
            "from tb_emp " +
            "group by dno " +
            "having max(salary) >= :salary", nativeQuery = true)
    List<EmpGroupDto> selectGroupMax(@Param("salary") int salary);
    // 쿼리문 :뒤에 붙은게 매개변수임. :salary -> @Param("salary") 으로 받으면 됨
    //  :변수명 -> 함수명(@Param("변수") String 변수)👀


//    연습문제 8
//    job 이 manager 가 아니고, job별 월 급여 합계가 5000 이상 되는 사원의 정보를 출력
//    단, 월 급여 합계로 오름차순 정렬 (필요시 ,dto 이용)
    // SELECT JOB, SUM(SALARY) AS "직업 별 월 급여합계" FROM tb_emp
    // WHERE JOB NOT LIKE '%MANAGER%' GROUP BY JOB HAVING SUM(SALARY) >= 5000
    // ORDER BY SUM(sALARY) ASC;
    @Query(value = "SELECT JOB, SUM(SALARY) as sumsalary " +
            "FROM tb_emp " +
            "WHERE JOB NOT LIKE '%MANAGER%' " +
            "GROUP BY JOB " +
            "HAVING SUM(SALARY) >= 5000 " +
            "ORDER BY SUM(SALARY) ASC", nativeQuery = true)
    List<EmpGroupDto> selectGroupJobHaving();


//    연습문제 9
//    사원의 총 인원수와 최고급여를 출력
//    필요하면 ,dto를 이용
    // select count(*), max(e.salary) as "최고급여" from tb_emp e;
    @Query(value = "select count(e.eno) as countEno, max(e.salary) as MaxSalary from tb_emp e", nativeQuery = true)
    List<EmpGroupDto> selectGroupSumMax();


//    연습문제 10
//    사원 테이블에서 가장 오래된 사원의 압사일과 가장 빠른 사원의 입사일을 출력
//    필요하면 ,dto를 이용
    // select max(hiredate), min(hiredate) from tb_emp;
    @Query(value = "select max(e.hiredate) as MaxHiredate, min(e.hiredate) as MinHiredate " +
            "from tb_emp e ", nativeQuery = true)
    List<EmpGroupDto> selectHiredate();








}
