package com.example.jpacustomexam.service.exam03;

import com.example.jpacustomexam.dto.DeptGroupDto;
import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.repository.exam03.Dept03Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * packageName : com.example.jpaexam.service.exam01
 * fileName : DeptService
 * author : juhee
 * date : 2022-10-20
 * description : 부서 업무 서비스 클래스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Service : 자동으로 객체 만들어주는 어노테이션
@Service
public class Dept03Service {
    // 객체 생성
    @Autowired
    Dept03Repository deptRepository;  // JPA CRUD 함수가 있는 인터페이스 객체


    // 예제 1.
    // pageable을 매개변수로 받았기때문에 똑같이 매개변수로 넘겨줌
    public Page<Dept> findAllByOrderByDnoDesc(Pageable pageable){
        Page<Dept> page = deptRepository.findAllByOrderByDnoDesc(pageable);

        return page;
    }


    // 연습문제 1.
    // 전체 부서정보 조회 시 페이징 처리
    public Page<Dept> getDeptAllPage(Pageable pageable){
        // findAll : 쿼리 메소드 안만들어도 됨(내장함수)
        Page<Dept> page = deptRepository.findAll(pageable); // findAll(페이징객체) 있음

        return page;
    }

    // 연습문제 2
    // 부서명(dname)으로 부서 정보 조회 페이징 처리(like 검색)
    public Page<Dept> findAllByDnameContaining(String dname, Pageable pageable){

        Page<Dept> page = deptRepository.findAllByDnameContaining(dname, pageable);

        return page;
    }


    /////////////////////////////////////////////////////////////////////////////////
//    어노테이션 @Query 를 이용한 페이징 처리 (@Query  -> 페이징처리)
    // @Query 이용 페이징 처리 함수
    // 예제 1 : dname, loc로 like 검색을 하고, dname으로 정렬한 데이터를 페이징하세요
    public Page<Dept> selectByDnameAndLocPage(String dname,
                                              String loc,
                                              Pageable pageable){

        Page<Dept> page = deptRepository.selectByDnameAndLocPage(dname, loc, pageable);

        return page;
    }
    /////////////////////////////////////////////////////////////////////////////////////


    // 예제 3 : @Query 작성
    public Page<DeptGroupDto> selectByCustomDeptPage(Pageable pageable) {

        Page<DeptGroupDto> page = deptRepository.selectByCustomDeptPage(pageable);

        return page;
    }


    // 예제 4 : @Query 작성
    public Page<DeptGroupDto> selectByCasePage(Pageable pageable) {

        Page<DeptGroupDto> page = deptRepository.selectByCasePage(pageable);

        return page;
    }


}
