package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.model.exam04.QDepartment;
import com.example.jpacustomexam.model.exam04.QEmployee;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Query dsl 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Dept07Repository extends JpaRepository<Department, Integer>, Dept07RepositoryCustom {
// JPA 함수와 쿼리dsl 함수 같이 쓸 수 있도록 둘다 상속받음*****

    
        // 여기 바로 네이티브쿼리 넣었지만.. 쿼리dsl 사용을 위해 Dept07RepositoryCustom 를 상속받음
        // 작성은 Dept07RepositoryCustom만 상속받은 곳(Dept07RepositoryCustomImpl)에서 함

//        public class Dept07RepositoryCustomImpl implements Dept07RepositoryCustom{
//
//            // JPAQueryFactory는 외부 쿼리dsl 라이브러리 설치시 자동으로 생성. 그 객체 가져옴.
//            @Autowired
//            private JPAQueryFactory queryFactory;
//
//
//            // 쿼리dsl에서 자동으로 만들어 줌
//            // Querydsl 을 위한 Q객체 가져오기
//            private QDepartment department = QDepartment.department;
//            private QEmployee employee = QEmployee.employee;
//
//            // 아래 쿼리dsl을 이용해서 만든 함수들. dept07RepositoryCustom을 상속받아야 객체 가져옴

}



