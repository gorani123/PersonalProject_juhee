package com.example.jpacustomexam.repository.exam03;

import com.example.jpacustomexam.dto.DeptGroupDto;
import com.example.jpacustomexam.model.Dept;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : JPA 페이징 처리 함수 만들기
 *     😦페이징 처리? 한 번에 화면에 보여줄 개수를 1페이지로 정해서 프로그램에서 나타내는 것을 의미
 *          page : 현재 페이지 번호
 *          size : 전체 페이지 수
 *          currentpage : 현재 페이지 번호
 *          totalItems : (내부적) 전체 데이터 건수
 *          totalpages : (내부적) 전체 페이지 수
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// 😦
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
@Repository
public interface Dept03Repository extends JpaRepository<Dept, Integer> {
    // exam03
//    1 : 쿼리 메소드 방식 이용
//    예제 1) 전체 부서 정보 조회 시 페이징 처리 함수

    // 페이지(Page) 사용법
    // Page<클래스명> 함수명(Pageable pageable)
    // 리턴값이 Page
    // 매개변수로 객체 Pageable 사용
    // 페이지 객체를 사용하면 JPA 쿼리를 자동 생성함

    // 쿼리메소드 함수 만들기            (매개변수)
    Page<Dept> findAllByOrderByDnoDesc(Pageable pageable);


    // 연습문제 1
//    findAll : 전체 부서조회 함수에 페이징 처리 로직을 추가하세요
//    URL 테스트 : http://localhost:8000/exam03/dept/desc/paging?page=0&size=2
    // findAll(Pageable pageable) 기본함수로 제공하므로 만들 필요 없음


    // 문제 2 (쿼리메소드 -> 페이징처리)
//    부서명(dname)으로 부서 정보 조회 페이징 처리(like 검색)
//    매개변수 2개(dname, pageable)
    Page<Dept> findAllByDnameContaining(String dname, Pageable pageable);


/////////////////////////////////////////////////////////////////////////////////
//    어노테이션 @Query 를 이용한 페이징 처리 (@Query  -> 페이징처리)
/////////////////////////////////////////////////////////////////////////////////
    // @Query 이용 페이징 처리 함수
    // 예제 1 : native 쿼리
    // dname, loc로 like 검색을 하고, dname으로 정렬한 데이터를 페이징하세요
//    nativeQuery = true 일 경우(일반 sql문 사용할 경우)
//    👀페이징 처리를 위해 옵션추가 필요 countQuery = "카운트 쿼리"👀
//    countQuery : 테이블 총 건수(컬럼 갯수) 세는 것. select절을 select count(*)로 받고, 뒤의 조건절 그대로 입력

    // sql : select * from tb_dept d where dname like '%S%' and loc like '%N%' order by d.dname;
    @Query(value = "select d.*  " +
            "from tb_dept d " +
            "where d.dname like %:dname% " +
            "and d.loc like %:loc% " +
            "order by d.dname"

            ,countQuery = "select count(*)  " +
            "from tb_dept d " +
            "where d.dname like %:dname% " +
            "and d.loc like %:loc% " +
            "order by d.dname"
            ,nativeQuery = true)
    Page<Dept> selectByDnameAndLocPage(@Param("dname") String dname,
                                       @Param("loc") String loc,
                                       Pageable pageable);

    // 참고예제 1-2 : 객체 쿼리(조인, 그룹 안하는 간단한 건 이게 더 편함)
    // 객체 쿼리 페이징 처리 : countQuery 옵션 없음
    // 객체 쿼리 특징 : 테이블명 -> 클래스명(tb_dept -> Dept), 컬럼명 -> 속성(필드)명, * 안 씀, 대소문자 구분
//    @Query(value = "select d  " +
//            "from Dept d " +
//            "where d.dname like %:dname% " +
//            "and d.loc like %:loc% " +
//            "order by d.dname")
//    Page<Dept> selectByDnameAndLocPage(@Param("dname") String dname,
//                                       @Param("loc") String loc,
//                                       Pageable pageable);

    
    // 예제 3 : @Query 작성
//    아래와 같이 출력되는 함수에 페이징 처리 로직을 구현하세요 (dto 이용)
//    결과출력) 
//    "dnoVar" : 부서번호는 10번
//    "dnameVar" : 부서명은 ACCOUNTING
//    "locVar" : 부서위치는 NEW YORK
//    "textVar" : 모든 부서정보를 출력했습니다.
    //    sql 내장함수 문자열 붙이기 함수 concat('문자열', 컬럼)이용. 또는 'Oracle' || 'Mania' 이용
    //    countQuery : 테이블 총 건수 세는 것. select절을 select count(*)로 받고, from절 뒤의 조건절 그대로 입력
    //                 모두 select 절이기 때문에 select count(*) from tb_Dept d 로 줄여짐

    @Query(value = "select concat('부서번호는 ', d.dno) as dnoVar, " +
            "concat('부서명은 ', d.dname) as dnameVar, " +
            "concat('부서위치는 ',d.loc) as locVar, " +
            "'모든 부서정보를 출력했습니다.'  as textVar " +
            "from tb_dept d "
            ,countQuery = "select count(*) from tb_dept d " // Page처리, countQuery추가 . count(*) 컬럼 갯수
            ,nativeQuery = true
    )
    Page<DeptGroupDto> selectByCustomDeptPage(Pageable pageable);
    // 함수를 모델(Dept 객체)이 아닌 DeptGroupDto에 저장


    // 예제 4 : @Query 작성
//    아래와 같이 출력되는 함수에 페이징 처리 로직을 구현하세요
//@Query(value = "select d.dno" +
//        "     ,case when d.dno < 20 then '연말 보너스 : 100%'" +
//        "     when d.dno > 20 then '연말 보너스 : 200%'" +
//        "     else '연말 보너스 : 없음'" +
//        "     end as incentive " +
//        "from tb_dept d "
//        , nativeQuery = true)
//List<DeptGroupDto> selectByCase();
    // when :dno < 20 로 받아도 됨
    @Query(value = "select d.dno" +
        "     ,case when d.dno < 20 then '연말 보너스 : 100%'" +
        "     when d.dno > 20 then '연말 보너스 : 200%'" +
        "     else '연말 보너스 : 없음'" +
        "     end as incentive " +
        "from tb_dept d "
        ,countQuery = "select count(*) from tb_dept d "  // 다 select절이니까 (from절 뒤에 조건절 없으니)
        , nativeQuery = true)

    Page <DeptGroupDto> selectByCasePage(Pageable pageable);



}



