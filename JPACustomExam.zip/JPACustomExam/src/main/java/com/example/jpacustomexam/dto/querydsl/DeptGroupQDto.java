package com.example.jpacustomexam.dto.querydsl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * packageName : com.example.jpacustomexam.dto.querydsl
 * fileName : DeptGroupQDto
 * author : ds
 * date : 2022-10-28
 * description : 쿼리dsl에서 사용하는 DTO 클래스 - 속성 정의
 *                                              Data Transfer Object
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-28         ds          최초 생성
 */
// 롬북 !!!!!!!!!!!!!!!!!!
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DeptGroupQDto {

    // 예제 3 : sum, avg, max, min 속성 필요 , count도 추가*****
    // 속성 (DTO 클래스에서는 속성만 정의)
    Long countVar;  // querydsl 에서 Long 자료형을 사용함 _count() 함수 일 경우
    Integer sumVar;
    Double avgVar;
    Integer maxVar;
    Integer minVar;

    // Dept07RepositoryCustomImpl 클래스의 querydslByGroupfunc()함수에서 쿼리dsl 사용해서 select할 때 속성 순서 맞춰야 함!!!


    // 10/28 만드는 순서*****  (별다섯개로 검색)
// model(exam04폴더의 Department) ->  Dept07Repository
// -> Dept07RepositoryCustom -> (QUerydslConfig) ->  Dept07RepositoryCustomImpl  --> DeptGroupQDto(가공데이터 출력하려고 만듦) --> Dept07RepositoryCustomImpl
// -> Dept07Service(07리파지토리 함수 받아서 정의)  -> Dept07Controller(07서비스의 함수 불러와서 실행)


    // 10/31
    // Dept07RepositoryCustomImpl - 예제 5
    // upperDname, lowerDname, substrDname
    String upperDname;
    String lowerDname;
    String substrDname;


    // 예제 6 : Case When
    String caseString;


    // 예제 7 : dno grouping
    // dno, dnoCount
    // Querydsl 은 count()함수의 리턴값의 자료형이 long(Long) 임!!!👀
    Integer dno;
    Long dnoCount;



}
