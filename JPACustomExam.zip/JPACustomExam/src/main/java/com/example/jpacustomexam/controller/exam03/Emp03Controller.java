package com.example.jpacustomexam.controller.exam03;

import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.service.exam03.Emp03Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName : com.example.jpacustomexam.controller.exam03
 * fileName : EmpController
 * author : juhee
 * date : 2022-10-24
 * description :  Emp Rest 컨트롤러
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam03")
public class Emp03Controller {

    @Autowired
    Emp03Service empService;


    // 1
    // URL 테스트 : http://localhost:8000/exam03/.../paging?page=0&size=2
    // 정렬(sort) :  http://localhost:8000/exam03/.../pging?page=0&size=2&sort=dno,desc
    @GetMapping("/emp/all/paging")
    public ResponseEntity<Object> getEmpAllPage(Pageable pageable){

        try{
            // 리턴값 Page
            Page<Emp> page = empService.findAll(pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장

            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                // 데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 2
    // URL 테스트 : http://localhost:8000/exam03/.../paging?page=0&size=2
    // 정렬(sort) :  http://localhost:8000/exam03/.../paging?page=0&size=2&sort=dno,desc
    @GetMapping("/emp/ename/desc/paging")
    public ResponseEntity<Object> getEmpByEnameDescPage(Pageable pageable){

        try{
            // 리턴값 Page
            Page<Emp> page = empService.findAllByOrderByEnameDesc(pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 3
    // URL 테스트 : http://localhost:8000/exam03/emp/...?page=0&size=2&sort=dno,desc
    @GetMapping("/emp/salary/first/{first}/last/{last}/paging")
    public ResponseEntity<Object> getEmpBySalaryBetweenPage(@PathVariable int first,
                                                            @PathVariable int last,
                                                            Pageable pageable){

        try{
            // 리턴값 Page
            Page<Emp> page = empService.findAllBySalaryBetween(first, last, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 4
    // URL 테스트 : http://localhost:8000/exam03//emp/ename/{ename}/paging?page=0&size=2
    @GetMapping("/emp/ename/{ename}/paging")
    public ResponseEntity<Object> getEmpByEnameContainingPage(@PathVariable String ename,
                                                            Pageable pageable)
    {
        try{
            // 리턴값 Page
            Page<Emp> page = empService.findAllByEnameContaining(ename, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            // 로직 추가 : data +
            //            currentPage(현재 페이지),
            //            totalItems(총 데이터 건수),
            //            totalPages(총 페이지 수),
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 5
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
    @GetMapping("/emp/dno/{dno}/salary/{salary}/paging")
    public ResponseEntity<Object> getEmpByDnoSalaryPage(@PathVariable int dno,
                                                            @PathVariable int salary,
                                                            Pageable pageable){

        try{
            // 리턴값 Page
            Page<Emp> page = empService.findAllByDnoAndSalaryGreaterThanEqual(dno, salary, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

   // 6
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
    @GetMapping("/emp/salary/between/{first}/{last}/paging")
    public ResponseEntity<Object> selectBySalaryPage(@PathVariable int first,
                                                     @PathVariable int last,
                                                     Pageable pageable){
        try{
            // 리턴값 Page
            Page<Emp> page = empService.selectBySalaryPage(first, last, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 7
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
    @GetMapping("/emp/hiredate/{start}/{end}/paging")
    public ResponseEntity<Object> selectByHiredatePage(@PathVariable String start,
                                                       @PathVariable String end,
                                                       Pageable pageable){
        try{
            // 리턴값 Page
            Page<Emp> page = empService.selectByHiredatePage(start, end, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

 // 8
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
    @GetMapping("/emp/salary/{first}/{last}/dno/{dno1}/{dno2}/paging")
    public ResponseEntity<Object> getBySalaryDnoPage(@PathVariable int first,
                                                     @PathVariable int last,
                                                     @PathVariable int dno1,
                                                     @PathVariable int dno2,
                                                     Pageable pageable){
        try{
            // 리턴값 Page
            Page<Emp> page = empService.selectBySalaryDnoPage(first, last, dno1, dno2, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


 // 9
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
//    @GetMapping("/emp/hiredate/{start}/{last}/paging")
//    public ResponseEntity<Object> selectByHiredateBetween(@PathVariable int start,
//                                                       @PathVariable int last,
//                                                       Pageable pageable){

//    Page<Emp> page = empService.selectByHiredateContainingPage(start, last, pageable);


    @GetMapping("/emp/hiredate/{hiredate}/paging")
    public ResponseEntity<Object> selectByHiredateContainingPage(@PathVariable int hiredate, Pageable pageable){
        try{
            // 리턴값 Page
            Page<Emp> page = empService.selectByHiredateContainingPage(hiredate, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 10
    // URL 테스트 : http://localhost:8000/exam03/emp/.../paging?page=0&size=2
    @GetMapping("/emp/commission/{commission}/paging")
    public ResponseEntity<Object> getselectByCommission(@PathVariable int commission,
                                                       Pageable pageable){
        try{
            // 리턴값 Page
            Page<Emp> page = empService.selectByCommission(commission, pageable);

            // 추가속성(페이지 정보)를 Map 자료구조에 담아서 전송(클라이언트에게)
            Map<String, Object> response = new HashMap<>();
            response.put("dept", page.getContent());    // 부서테이블의 페이징된 데이터, dept 이름으로 보내기
            response.put("currentPage", page.getNumber());    // 현재 페이지 번호(0번부터 시작)
            response.put("totalItems", page.getTotalElements());    // 총 데이터 수 (부서테이블, 4건)
            response.put("totalPages", page.getTotalPages());    // 총 페이지 수
            // Map객체.put("키이름", 값) : 맵 객체에 "키이름"으로 정보 저장


            // list배열이 비어있지 않으면
            if(page.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e){
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


}

