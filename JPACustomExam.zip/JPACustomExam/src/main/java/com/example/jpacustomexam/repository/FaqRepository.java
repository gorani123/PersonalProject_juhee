package com.example.jpacustomexam.repository;

import com.example.jpacustomexam.model.Faq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * packageName : com.example.jpaexam.repository
 * fileName : FaqRepository
 * author : juhee
 * date : 2022-10-21
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
@Repository                                      // 모델명  @Id 자료형
public interface FaqRepository extends JpaRepository<Faq, Integer> {

}
