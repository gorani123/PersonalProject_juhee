package com.example.jpacustomexam.dto;

import lombok.*;

/**
 * packageName : com.example.jpacustomexam.dto
 * fileName : DeptEmpCDto
 * author : juhee
 * date : 2022-10-27
 * description : 객체 쿼리(JPQL)의 결과를 저장할 DTO 클래스 (native query 의 결과를 저장할 DTO 인터페이스)
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DeptEmpCDto {

    // 부서 속성
    private Integer dno;
    private String dname;
    private String loc;

    // 사원 속성
    private Integer eno;
    private String ename;
    private String job;
    private Integer manager;
    private String hiredate;
    private Integer salary;
    private Integer commission;


    // 생성자를 이용해서 필요한 속성만 출력하기
    // Alt + Insert
    public DeptEmpCDto(Integer dno, String dname, String loc, Integer eno, String ename, Integer salary) {
        this.dno = dno;
        this.dname = dname;
        this.loc = loc;
        this.eno = eno;
        this.ename = ename;
        this.salary = salary;
    }

    // Dept07RepositoryCustomImpl 예제 8
    // 위의 속성으로 출력 가능
}
