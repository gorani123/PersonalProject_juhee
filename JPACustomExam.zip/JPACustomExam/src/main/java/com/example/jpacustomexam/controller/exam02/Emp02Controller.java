package com.example.jpacustomexam.controller.exam02;

import com.example.jpacustomexam.dto.EmpGroupDto;
import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.service.exam02.Emp02Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.controller.exam02
 * fileName : EmpController
 * author : juhee
 * date : 2022-10-24
 * description :  Emp Rest 컨트롤러
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam02")
public class Emp02Controller {

    @Autowired
    Emp02Service empService;


    // 연습문제 1 : salary
    @GetMapping("/emp/select/{ename}")
    public ResponseEntity<Object> selecByEname(@PathVariable String ename) {

        try {
            List<Emp> list = empService.selecByEname(ename);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 2
    @GetMapping("/emp/desc/asc")
    public ResponseEntity<Object> selectDescAsc() {

        try {
            List<Emp> list = empService.selectDescAsc();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 3
    @GetMapping("/emp/salary/{salary}")
    public ResponseEntity<Object> selectSalary(@PathVariable int salary) {

        try {
            List<Emp> list = empService.selectSalary(salary);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 4
    @GetMapping("/emp/hiredate/{first}/{last}")
    public ResponseEntity<Object> selectHiredate(@PathVariable String first,
                                                 @PathVariable String last) {

        try {
            List<Emp> list = empService.selectHiredate(first, last);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 5
    @GetMapping("/emp/selectGroup")
    public ResponseEntity<Object> selectGroupDnoJob() {

        try {
            List<EmpGroupDto> list = empService.selectGroupDnoJob();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 6
    @GetMapping("/emp/group/avg")
    public ResponseEntity<Object> selectAvg() {

        try {
            List<EmpGroupDto> list = empService.selectGroupDnoTrunc();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 7
//    @GetMapping("/emp/group/max")
//    public ResponseEntity<Object> selectGroupMax() {
//
//        try {
//            List<EmpGroupDto> list = empService.selectGroupMax();
//
//            // list배열이 비어있지 않으면
//            if (list.isEmpty() == false) {
//                //                         데이터 + 성공 메시지 전송
//                return new ResponseEntity<>(list, HttpStatus.OK);
//            } else {
//                // 데이터 없음 메시지 클라이언트에게 전송
//                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
//            }
//
//        } catch (Exception e) {
//            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
//        }
//    }
    @GetMapping("/emp/group/maxSalary/{salary}")
    public ResponseEntity<Object> selectGroupMax(@PathVariable int salary) {

        try {
            List<EmpGroupDto> list = empService.selectGroupMax(salary);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 8
    @GetMapping("/emp/sum/job/group")
    public ResponseEntity<Object> selectGroupJobHaving() {

        try {
            List<EmpGroupDto> list = empService.selectGroupJobHaving();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

  // 연습문제 9
    @GetMapping("/emp/sum/MaxSalary")
    public ResponseEntity<Object> selectGroupSumMax() {

        try {
            List<EmpGroupDto> list = empService.selectGroupSumMax();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 10
    @GetMapping("/emp/hiredate/max/min")
    public ResponseEntity<Object> selectHiredate() {

        try {
            List<EmpGroupDto> list = empService.selectHiredate();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }



}

