package com.example.jpacustomexam.repository.exam04;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.dto.DeptEmpDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Join 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Dept04Repository extends JpaRepository<Dept, Integer> {

    // 예제 1-1) 부서와 사원테이블 조인해서 보여주기
    // DTO 필요(nativeQuery=true일 경우, 인터페이스로 DTO 만들어야 함_false면 클래스로)
    // 자동 import -> spring 붙은것 또는, java.util.* t 선택
    // nativeQuery : 일반 sql문
    @Query(value = "select d.*, e.eno, e.ename, e.salary " +
            "from tb_employee e, tb_department d " +
            "where e.dno = d.dno"
            , nativeQuery = true)
    List<DeptEmpDto> selectNativeJoin();


    // 예제 1-2) 객체쿼리
    // nativeQuery = false 쓰거나 생략 : 객체 쿼리(JPQL 쿼리)
    // DTO 필요, 클래스로!!
    // JPA 관계설정 : @ManyToOne 걸어야 아래 쿼리 가능
//    @Query(value = "select  " +
//            "new com.example.jpacustomexam.dto.DeptEmpCDto(d.dno, d.dname, d.loc, e.eno, e.ename, e.salary) " +
//            "from Employee e inner join e.department d")
//            List<DeptEmpCDto> selectJoin();
//    오류나서 데이터가 안 뜸..

    // 참고
    // 관계설정 없이(inner join e.department안하고) 객체 쿼리로 조인 사용 -> on 사용
    // on e.dno = d.dno
    @Query(value = "select  " +
            " new com.example.jpacustomexam.dto.DeptEmpCDto(d.dno, d.dname, d.loc, e.eno, e.ename, e.salary) " +
            "from Emp e inner join Dept d on e.dno = d.dno")
    List<DeptEmpCDto> selectJoin();
//    위에꺼랑 내용 같은데 이건 됨..


}



