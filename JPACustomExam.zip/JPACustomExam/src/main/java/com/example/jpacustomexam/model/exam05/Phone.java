package com.example.jpacustomexam.model.exam05;

import com.example.jpacustomexam.model.BaseTimeEntity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;

import javax.persistence.*;

/**
 * packageName : com.example.jpacustomexam.model.exam05
 * fileName : Person
 * author : Moon
 * date : 2022-10-27-027
 * description : @OneToOne 관계 설정을 위한 클래스
 *                  한사람당 핸드폰 1개
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27-027         Moon          최초 생성
 */
@Entity
@Table(name="TB_PHONE")
@SequenceGenerator(
        name= "SQ_PHONE_GENERATOR"
        , sequenceName = "SQ_PHONE"
        , initialValue = 1
        , allocationSize = 1
)
@Setter
@Getter
@ToString(exclude = "person")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicInsert
@DynamicUpdate
public class Phone {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE
            , generator = "SQ_PHONE_GENERATOR"
    )
    private Integer pno;
    @Column(columnDefinition = "VARCHAR2(255)")
    private String pname;
    @Column(columnDefinition = "VARCHAR2(255)")
    private String vendor;

    //    Phone 클래스 현재는 1개지만 향후 여러개가 될수 있음
//    여기에 FK(참조키/외래키)를 생성하는 것이 좋음
    @OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "상대클래스 기본키속성")
    @JoinColumn(name = "no")
    @JsonBackReference
    private Person person;
}

