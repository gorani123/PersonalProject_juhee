package com.example.jpacustomexam.service.exam01;

import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.repository.EmpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.service.exam01
 * fileName : EmpService
 * author : juhee
 * date : 2022-10-24
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
@Service
public class EmpService {
    @Autowired
    EmpRepository empRepository;  // JPA CRUD 함수가 있는 인터페이스 객체

    // 전체 조회 함수
    // empRepository. (점) 하면 JPA의 "기본함수들" 불러서 쓸 수 있음
    public List<Emp> findAll(){
        List<Emp> list = empRepository.findAll();

        return list;
    }

    // 연습문제 1
    public List<Emp> findAllDesc(){
        List<Emp> list = empRepository.findAllByOrderByEnoDesc();

        return list;
    }

    // 연습문제 2
    public List<Emp> findAllByEnameContainingOrderByEnameDesc(String ename){
        List<Emp> list = empRepository.findAllByEnameContainingOrderByEnameDesc(ename);

        return list;
    }

    // 연습문제 3
    public List<Emp> findAllByJobContainingOrderByJobDesc(String job){
        List<Emp> list = empRepository.findAllByJobContainingOrderByJobDesc(job);

        return list;
    }

    // 연습문제 4
    public List<Emp> findAllByJobAndDno(String job, int dno){
        List<Emp> list = empRepository.findAllByJobAndDno(job, dno);

        return list;
    }

    // 연습문제 5
    public List<Emp> findAllBySalaryBetweenOrderByEname(int first, int last){
        List<Emp> list = empRepository.findAllBySalaryBetweenOrderByEname(first, last);

        return list;
    }

    // 연습문제 6
    public List<Emp> findAllByJobIgnoreCase(String job){
        List<Emp> list = empRepository.findAllByJobIgnoreCase(job);

        return list;
    }

    // 연습문제 7
    public List<Emp> findAllByCommissionIsNotNull(){
        List<Emp> list = empRepository.findAllByCommissionIsNotNull();

        return list;
    }


    // 연습문제 8
    public List<Emp> findAllByOrderBySalaryDescEnameAsc(){
        List<Emp> list = empRepository.findAllByOrderBySalaryDescEnameAsc();

        return list;
    }

    // 연습문제 9
    public List<Emp> findAllBySalaryLessThanOrSalaryGreaterThan(int first, int second){
        List<Emp> list = empRepository.findAllBySalaryLessThanOrSalaryGreaterThan(first, second);

        return list;
    }

    // 연습문제 10
    public List<Emp> findAllByCommissionIsOrCommissionOrCommission(int first, int second, int last){
        List<Emp> list = empRepository.findAllByCommissionIsOrCommissionOrCommission(first, second, last);

        return list;
    }

}
