package com.example.jpacustomexam.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

/**
 * packageName : com.example.jpaexam.model
 * fileName : Dept
 * author : juhee
 * date : 2022-10-19
 * description : 부서 모델 클래스
 *                      JPA에서는 모델을 Entity(엔티티)라고 부름 (@Entity 어노테이션 사용하기 때문)
 * 😦
 * JPA_ 간단한 프로젝트시 아주 빠름(복잡한건오류나서잘안됨).         Mybatis는 복잡한 프로젝트시 편리
 * JPA 메커니즘 : 클래스를 대상으로 (속성대로) 테이블 자동 생성
 *                                                      비교) Mybatis : 개발자가 직접 자바소스에 sql문 작성
 *     기본 제공하는 함수들은 자동으로 CRUD sql문을 만들어 줌
 *     sql문 작성에 필요한 노력을 절약할 수 있음
 *     (개발자는 제공되는 함수만 호출하면 됨. sql문은 JPA 라이브러리가 알아서 생성함)
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-19         juhee          최초 생성
 */
// 😦 어노테이션 설명
// @Entity : 대상 클래스를 참고하여 DB에 물리 테이블을 생성함
// @Table(name = "테이블명") : 테이블 자동생성시, 테이블명(TB_DEPT)으로 생성됨(테이블명 직접지정). 물론 컬럼명도 직접지정 가능
// @SequenceGenerator(각종 속성) : Oracle DB 시퀀스 생성 시 사용할 속성들
// @DynamicInsert : insert 할 때, null인 컬럼을 제외해서 sql문을 자동으로 생성
// @DynamicUpdate : update 할 때, null인 컬럼을 제외해서 sql문을 자동으로 생성
// @Id : 기본키가 지정될 속성 (DB에 기본키를 자동으로 만들어 줌)
// @Column(columnDefinistion = "컬럼타입(개수)") : DB에 자동생성될 테이블의 컬럼 정보를 직접 지정(안하면 자동, 엉망으로 만들어 줌)
@Entity
@Table(name="TB_DEPT")      // 테이블명 ***
@SequenceGenerator(                 //👀 아래 @GenerateValue()에서 써준거 세부적으로 써줘야 함
        name= "SQ_DEPT_GENERATOR",
        sequenceName = "SQ_DEPT",
        initialValue = 1,
        allocationSize = 1
)
@Getter // 롬북
@Setter // 롬북
@NoArgsConstructor
// SQL문 자동생성시 null 컬럼데이터는 제외시키는 어노테이션: @DynamicInsert @DynamicUpdate
@DynamicInsert
@DynamicUpdate
public class Dept extends BaseTimeEntity {
    // JPA 의 특징 : 속성대로 테이블을 만들어 줌!! (my머시기는 안해줌)
    // JPA 의 특징 : 시퀀스도 자동으로 만들어 줌!!

    // 속성
    // @Id : 기본키(PrimaryKey). not null. 유일해야 함 (하나는 필수. 없으면 클래스명(Detp)에 빨간줄 뜸)
    // @GenerateValue(..SEQUENCE, ...) :오라클은 시퀀스 사용함 (시퀀스 사용_ORACLE, POSTGRE 등/ increment 사용_MYSQL, MARIA DB 등)
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_DEPT_GENERATOR") //👀
    private Integer dno;     // 부서번호(dno)

    @Column(columnDefinition = "VARCHAR2(255)")
    private String dname;    // 부서명(dname)

    @Column(columnDefinition = "VARCHAR2(255)")
    private String loc;      // 위치(loc)

}
