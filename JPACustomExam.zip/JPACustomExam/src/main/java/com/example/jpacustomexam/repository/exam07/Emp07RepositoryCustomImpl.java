package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.dto.querydsl.EmpGroupQDto;
import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.model.exam04.Employee;
import com.example.jpacustomexam.model.exam04.QDepartment;
import com.example.jpacustomexam.model.exam04.QEmployee;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ldap.embedded.EmbeddedLdapAutoConfiguration;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.repository.exam07
 * fileName : Dept07RepositoryCustomImpl
 * author : juhee
 * date : 2022-10-27
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
public class Emp07RepositoryCustomImpl implements Emp07RepositoryCustom {

    // JPAQueryFactory
    @Autowired
    private JPAQueryFactory queryFactory;


    // Querydsl 을 위한 Q객체 가져오기
    private QDepartment department = QDepartment.department;
    private QEmployee employee = QEmployee.employee;



//    예제 1 : ename like 검색하는 함수 정의
//    메서드 구현
//    체이닝 이용: .함수().함수()
    @Override
    public List<Employee> querydslByEname(String ename) {
        List<Employee> list = queryFactory
                .selectFrom(employee)                     // select문
                .where(
                        employee.ename.contains(ename)    // like검색
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


//    예제 2 : ename, job
    @Override
    public List<Employee> querydslByEnameAndJob(String ename, String job) {

        List<Employee> list = queryFactory
                .selectFrom(employee)             // select문
                .where(
                        employee.ename.contains(ename)    // like검색
                      ,employee.job.contains(job)       //and 대신 바로 ,써도 됨
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    ////////////////////////////////////////////////////////////////////////////////// 10/28
    // 문제 3 : 사원테이블의 급여(salary)의 (count, sum, avg, max, min) 값을 입력하세요
    // EmpGroupQDto 만들어서 위의 속성값들을 출력하는 함수를 만드세요.
    @Override
    public List<EmpGroupQDto> querydslByGroupfunc(){

        // 출력할 속성을 dto에 넣으니까 리턴값도 DeptGroupQDto 로 변경 *****
        List<EmpGroupQDto> list = queryFactory
//                속성 몇개만 select(출력) 할 때는 DTO 클래스 이용 (DTO 인터페이스 -> native query) (DTO 클래스 -> 객체쿼리, 쿼리dsl)
//                **dto에 querydsl 폴더에 DeptGroupQDto 만들기(sum, avg, max, min, count 속성 이 안에 정의)
//                 DTO : 속성 몇 개만 출력하거나, 가공된 데이터(그룹함수)를 출력하고 싶을 때 사용
//                      1) DTO 생성자를 이용해서 속성으로 저장(출력) : new 생성자(속성1, 속성2, ...)
//                      2) 이미 있는 속성을(필드) 이용해서 출력 : Projections.fields(DTO객체, 속성1, 속성2, ..속성들..)
                .select(
                        Projections.fields(
                                EmpGroupQDto.class,
                                employee.salary.count().as("countVar"),      // 자료는 employee
                                employee.salary.sum().as("sumVar"),          // EmpGroupQDto 의 속성 순서대로 입력!!
                                employee.salary.avg().as("avgVar"),
                                employee.salary.max().as("maxVar"),
                                employee.salary.min().as("minVar")
                        )
                )
                .from(employee)                   // (selectFrom = select All)
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    // 연습문제 4 : commission 이 500이상인 사원정보를 출력
    //  -> 정의 후 Emp07RepositoryCustom 리파지토리 인터페이스로 가서 구현 -> service -> controller
    @Override
    public List<Employee> querydslByCommissionGt(int commission){

        List<Employee> list = queryFactory
                .selectFrom(employee)             // select문
                .where(
                        employee.commission.gt(commission)      // .gt() : greater than ~보다 큰 (<-> .lt() : less than)
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    // 연습문제 5 : 1982년도에 입사한 사원 출력하기 (Between and)
    @Override
    public List<Employee> querydslByHiredate(String first, String last){

        List<Employee> list = queryFactory
                .selectFrom(employee)             // select문
                .where(
                        employee.hiredate.between(first, last)      // .between(a , b)
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    // 연습문제 6 : dno, job 별 월 급여 합계(sum)를 출력하는 함수 작성
    // groubBy(속성1, 속성2...)
    // groubBy( employee.department.dno.연산자(),   employee.job
    @Override
    public List<EmpGroupQDto> querydslByGroupDnoJob() {

        List<EmpGroupQDto> list = queryFactory
                .select(
                        Projections.fields(
                                EmpGroupQDto.class,                    // select dno, job, sum(salary) from tb_Department
                                employee.department.dno.as("dno"),  // 속성으로 들어올 값 dno 저장 (EmpGroupQDto에 속성있음)
                                employee.job.as("job"),             // 속성으로 들어올 값 job 저장
                                employee.salary.sum().as("sumSalary")
                        )
                )
                .from(employee)
                .groupBy(
                        employee.department.dno,    // dno로 그룹핑    // groub by dno, job
                        employee.job                // job으로 그룹핑
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행
        return list;
    }


    // 연습문제 7 : 동적 쿼리(다이나믹 쿼리) ename or job
    // 동적 쿼리(dynamic query) :  querydsl. 조건에 따라 쿼리문이 달라지는 것
    // s / m
    @Override
    public List<Employee> querydslByDynamicEname(String ename, String job) {

        // 다이나믹 뭐리 작성하기 : BooleanBuilder 클래스에서 동적조건부분(Where 절)을 만들 수 있음
        BooleanBuilder builder = new BooleanBuilder();

        // ename 이 null 이 아니면 where ename like '%ename%' 추가 (like = contains)
        if( ename != null) {
            builder.and(employee.ename.contains(ename));
        }
        // job가 null이 아니면 where job like '%job%' 추가
        if( job != null) {
            builder.and(employee.job.contains(job));
        }

        return queryFactory
                .selectFrom(employee)
                .where(builder) // 위에서 만든 동적으로 만들어지는 where 절 추가 (builder)
                .fetch(); // 조회 실행
    }


    // 연습문제 8 : 급여가 2000~3000 사이가 아닌 사원을 출력하는 함수
    @Override
    public List<Employee> querydslBySalaryNotBetween(int salary1, int salary2){

        List<Employee> list = queryFactory
                .selectFrom(employee)             // select문
                .where(
                        employee.salary.notBetween(salary1,salary2)
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

}
