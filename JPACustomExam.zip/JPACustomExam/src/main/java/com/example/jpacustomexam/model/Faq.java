package com.example.jpacustomexam.model;

import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

/**
 * packageName : com.example.jpaexam.model
 * fileName : Faq
 * author : juhee
 * date : 2022-10-21
 * description : Faq 모델=엔티티 클래스
 *                 모델 - REPOSITORY - 서비스 -컨트롤러(Restcontroller_json형태로출력) crud
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
// 종합 예제
//    Faq 게시판 제작
//    모델을 아래와 같이 정의하고 서비스와 컨트롤러 클래스를 정의하세요(CRUD 함수 모두 포함)
//    단, 번호(no)는 시퀀스로 생성되고 초기값1, 1씩 증가, 생성일자/수정일자 자동 반영
//    Restcontroller 이용
    
@Entity
@Table(name = "TB_FAQ")
@SequenceGenerator(name = "SQ_FAQ_GENERATOR"
                ,sequenceName = "SQ_FAQ"    // db에서 생성되는 시퀀스 이름
                ,initialValue = 1           // 초기값
                ,allocationSize = 1         // 1씩 증가
)
@Setter
@Getter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicInsert
@DynamicUpdate
public class Faq extends BaseTimeEntity {
    
    // 속성
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE
                 ,generator = "SQ_FAQ_GENERATOR"
    )
    @Column(columnDefinition = "NUMBER")
    private Integer no;         // faq 번호
    @Column(columnDefinition = "VARCHAR2(255)")
    private String title;   //제목
    @Column(columnDefinition = "VARCHAR2(255)")
    private String content; // 내용
}
