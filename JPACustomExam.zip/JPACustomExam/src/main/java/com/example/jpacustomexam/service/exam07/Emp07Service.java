package com.example.jpacustomexam.service.exam07;

import com.example.jpacustomexam.dto.querydsl.EmpGroupQDto;
import com.example.jpacustomexam.model.exam04.Employee;
import com.example.jpacustomexam.repository.exam07.Dept07Repository;
import com.example.jpacustomexam.repository.exam07.Emp07Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.service.exam07
 * fileName : Dept07Service
 * author : juhee
 * date : 2022-10-27
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
@Service
public class Emp07Service {

    @Autowired
    Emp07Repository empRepository;

    // 예제 1)
    //    조인 결과 쿼리 함수
    public List<Employee> querydslByEname(String ename) {
        List<Employee> list = empRepository.querydslByEname(ename);

        return list;
    }

    // 예제 2)
    //    조인 결과 쿼리 함수
    public List<Employee> querydslByEnameAndJob(String ename, String job) {
        List<Employee> list = empRepository.querydslByEnameAndJob(ename, job);

        return list;
    }


    // 문제 3)
    //    조인 결과 쿼리 함수
    public List<EmpGroupQDto> querydslByGroupfunc() {
        List<EmpGroupQDto> list = empRepository.querydslByGroupfunc();

        return list;
    }


    // 문제 4)
    //    조인 결과 쿼리 함수
    public List<Employee> querydslByCommissionGt(int commission) {
        List<Employee> list = empRepository.querydslByCommissionGt(commission);

        return list;
    }


    // 문제 5)
    //    조인 결과 쿼리 함수
    public List<Employee> querydslByHiredate(String first, String last) {
        List<Employee> list = empRepository.querydslByHiredate(first, last);

        return list;
    }


    // 문제 6)
    //    조인 결과 쿼리 함수 : dno, job 별 월 급여 합계(sum)
    public List<EmpGroupQDto> querydslByGroupDnoJob() {
        List<EmpGroupQDto> list = empRepository.querydslByGroupDnoJob();

        return list;
    }


    // 문제 7)
    //    조인 결과 쿼리 함수 : 동적쿼리
    public List<Employee> querydslByDynamicEname(String ename, String job) {
        List<Employee> list = empRepository.querydslByDynamicEname(ename, job);

        return list;
    }

    // 문제 8)
    //    조인 결과 쿼리 함수
    public List<Employee> querydslBySalaryNotBetween(int salary1, int salary2) {
        List<Employee> list = empRepository.querydslBySalaryNotBetween(salary1, salary2);

        return list;
    }



}
