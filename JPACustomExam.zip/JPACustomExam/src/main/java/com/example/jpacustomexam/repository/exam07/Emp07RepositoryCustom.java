package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.dto.querydsl.EmpGroupQDto;
import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.model.exam04.Employee;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Join 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Emp07RepositoryCustom {

    // querydsl 이용
    // 연습문제 1 : ename like 검색해서 사원테이블 출력하는 함수 정의
    List<Employee> querydslByEname(String ename);

    // 연습문제 2 : ename like 검색해서 사원테이블 출력하는 함수 정의
    List<Employee> querydslByEnameAndJob(String ename, String job);


    ////////////////////////////////////////////////////////////////////
    // 연습문제 3  ---> 컨트롤러
    List<EmpGroupQDto> querydslByGroupfunc();

    // 연습문제 4 : commission 이 500이상인 사원정보를 출력
    public List<Employee> querydslByCommissionGt(int commission);

    // 연습문제 5 : hiredate 1982년인 사원정보를 출력
    public List<Employee> querydslByHiredate(String first, String last);


    // 연습문제 6 : dno, job 별 월 급여 합계(sum)
    public List<EmpGroupQDto> querydslByGroupDnoJob();

    // 연습문제 7 : 동적쿼리
    public List<Employee> querydslByDynamicEname(String ename, String job);


    // 연습문제 8
    public List<Employee> querydslBySalaryNotBetween(int salary1, int salary2);


    }


