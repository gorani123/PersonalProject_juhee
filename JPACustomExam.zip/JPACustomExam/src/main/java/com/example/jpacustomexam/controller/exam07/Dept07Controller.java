package com.example.jpacustomexam.controller.exam07;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.service.exam07.Dept07Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Dept07Controller
 * author : juhee
 * date : 2022-10-21
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중요
 * 요약 : 😦
 *      사용자 정의(custom) 함수 _ Repository에 작성
 *   1. 쿼리 메소드 : 자동으로 사용자정의 sql 문을 작성하기 위해 사용
 *      목적 : 기본 함수보다 다양한 sql문을 작성하기 위해 사용
 *      사용법 : 함수이름으로 sql 문장을 작성함 ( Repository 안에 함수명만 작성 )
 *      ex) JPA 클래스 === 대상 테이클
 *      ex) find == select
 *      ex) all = *
 *      ex) by == from
 *      ex) 속성 = where 컬럼
 *      ex) orderBy == order by
 *      ex) 속성 desc = 컬럼 desc
 *
 *   2. @Query(쿼리문)함수명() : 쿼리문에 해당되는 부분을 직접 개발자가 작성(sql문)
 *      쿼리문의 매개변수 전달 ->👀 :변수   => 함수명(@Param("변수") String 변수
 *      select * from tb_dept where dno = :변수명
 *      List<Dept> selectAll(@Param(변수명) 타입 변수명
 *
 *       2-1) nativeQuery = true : 일반 sql 문으로 작성
 *       2-2) nativeQuery = false, 생략 : 객체 쿼리
 *                                      ( 테이블명, 컬럼명 대신 클래스명, 속성(필드명) 사용 )
 *
 *   3. 페이징 처리 함수
 *      목적 : 전체 데이터를 화면에 출력하면 성능과 가독성이 떨어지므로, 몇 건씩 끊어서 보여주는 것
 *      페이징 객체 :
 *          1) 매개변수 페이징 객체 : Pageable
 *          2) 리턴될 페이징 객체 : Page<객체자료형>
 *      속성 : page = 현재페이지(0부터 시작) , size = 한 페이지에 보여 줄 데이터 수 (url 매개변수로 전달됨)
 *      클라이언트로 전송 할 데이터 : Map 자료구조 이용
 *          1) 데이터: 부서, 사원 등
 *          2) currentPage : 현재 페이지 수(정보) (총 10페이지 중 현재 3페이지에 위치)
 *          3) totalItem : 전체 데이터 수
 *          4) totalPages : 전체 페이지 수
 *
 *  조인, 동적쿼리
 *
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam07")
public class Dept07Controller {

//     스프링부트가 가동될 때 자동생성된 서비스 객체를 @AUtowired 로 받아오기(new 연산자로 직접 생성하는 대신)
//     DI(의존성 주입_위와 같은 말) (@Autowired)
    @Autowired
    Dept07Service deptService;      // 서비스객체 생성했으니, 서비스객체의 함수를 받아오는것!!!

    // 예제 1 : 네이티브 쿼리 이용 조인 함수
    @GetMapping("/dept/querydsl/dname/{dname}")
    public ResponseEntity<Object> querydslByDname(@PathVariable String dname){

        try {
            List<Department> list = deptService.querydslByDname(dname);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 2
    @GetMapping("/dept/querydsl/dname/{dname}/loc/{loc}")
    public ResponseEntity<Object> querydslByDnameAndLoc(@PathVariable String dname,
                                                  @PathVariable String loc){

        try {
            List<Department> list = deptService.querydslByDnameAndLoc(dname, loc);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    ///////////////////////////////////////////////////////////////////////////////
    // 예제 3 : sum, avg, max, min 속성 필요 , count도 추가*****
    @GetMapping("/dept/querydsl/groupfunc")
    public ResponseEntity<Object> querydslByGroupfunc(){

        try {
            List<DeptGroupQDto> list = deptService.querydslByGroupfunc();

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 예제 4 : 부서번호가 20보다 큰 부서들의 정보 출력
//    http://localhost:8000/exam07/dept/greaterthan/dno?dno=20
//    @GetMapping("/dept/greaterthan/dno")

    @GetMapping("/dept/querydsl/dept/dno/{dno}")
    public ResponseEntity<Object> querydslByDeptGt(@PathVariable int dno){

        try {
            List<Department> list = deptService.querydslByDeptGt(dno);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 예제 5
    @GetMapping("/dept/querydsl/basicfunc")
    public ResponseEntity<Object> QuerydslByBasicFunc(){

        try {
            List<DeptGroupQDto> list = deptService.QuerydslByBasicFunc();

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 예제 6 : Case When
    @GetMapping("/dept/querydsl/casewhen")
    public ResponseEntity<Object> QuerydslByCaseWhen(){

        try {
            List<DeptGroupQDto> list = deptService.QuerydslByCaseWhen();

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


 // 예제 7 : Group
    @GetMapping("/dept/querydsl/grounp/{dnoCount}")
    public ResponseEntity<Object> querydslByDnoGroup(@PathVariable long dnoCount){

        try {
            List<DeptGroupQDto> list = deptService.querydslByDnoGroup(dnoCount);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 8 : 조인
    @GetMapping("/dept/querydsl/join/dname/{dname}")
    public ResponseEntity<Object> querydslByDnameJoin(@PathVariable String dname){

        try {
            List<DeptEmpCDto> list = deptService.querydslByDnameJoin(dname);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 8-2 : 조인
    @GetMapping("/dept/querydsl/join2/dname/{dname}")
    public ResponseEntity<Object> querydslByDnameJoin2(@PathVariable String dname){

        try {
            List<DeptEmpCDto> list = deptService.querydslByDnameJoin2(dname);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 9 : 서브쿼리
    @GetMapping("/dept/querydsl/dno/sub")
    public ResponseEntity<Object> querydslByDnoSub(){

        try {
            List<Department> list = deptService.querydslByDnoSub();

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 10 : 서브쿼리
    @GetMapping("/dept/querydsl/sub/dno/{dno}")
    public ResponseEntity<Object> querydslByDnoGoeSub(@PathVariable int dno){

        try {
            List<Department> list = deptService.querydslByDnoGoeSub(dno);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 예제 11 : 서브쿼리
    @GetMapping("/dept/querydsl/dynamic/dname/{dname}/loc/{loc}")
    public ResponseEntity<Object> querydslByDynamicName(@PathVariable String dname,
                                                        @PathVariable String loc){

        try {
            // 다이나믹 테스트
            dname = null;   // 강제 세팅
            loc = null;
            List<Department> list = deptService.querydslByDynamicName(dname, loc);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}



