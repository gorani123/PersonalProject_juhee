package com.example.jpacustomexam.service.exam02;

import com.example.jpacustomexam.dto.DeptGroupDto;
import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.repository.DeptRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * packageName : com.example.jpaexam.service.exam01
 * fileName : DeptService
 * author : juhee
 * date : 2022-10-20
 * description : 부서 업무 서비스 클래스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Service : 자동으로 객체 만들어주는 어노테이션
@Service
public class Dept02Service {
    // 객체 생성
    @Autowired
    DeptRepository deptRepository;  // JPA CRUD 함수가 있는 인터페이스 객체


    // 예제 1.
    public List<Dept> selectByDname(String dname){
        List<Dept> list = deptRepository.selectByDname(dname);

        return list;
    }

    // 예제 2.
    public List<Dept> selectByDnameAndLoc(String dname, String loc){
        List<Dept> list = deptRepository.selectByDnameAndLoc(dname, loc);

        return list;
    }

    // 예제 3.
    // Dept 모델 아니고 DeptGroupDto 라는 인터페이스 사용
    public List<DeptGroupDto> selectByGroupFunc(){
        List<DeptGroupDto> list = deptRepository.selectByGroupFunc();

        return list;
    }

    // 예제 4.
    // Dept 모델 아니고 DeptGroupDto 라는 인터페이스 사용
    public List<DeptGroupDto> selectByCustomDept(){
        List<DeptGroupDto> list = deptRepository.selectByCustomDept();

        return list;
    }

    // 예제 5
    // Dept 모델 아니고 DeptGroupDto 라는 인터페이스 사용
    public List<DeptGroupDto> selectByBasicFunc(){
        List<DeptGroupDto> list = deptRepository.selectByBasicFunc();

        return list;
    }

    // 예제 6
    // Dept 모델 아니고 DeptGroupDto 라는 인터페이스 사용
    public List<DeptGroupDto> selectByCase(){
        List<DeptGroupDto> list = deptRepository.selectByCase();

        return list;
    }



}
