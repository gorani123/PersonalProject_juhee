package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.model.exam04.Department;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Join 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Dept07RepositoryCustom {


    // 쿼리dsl을 사용하려고 만든 인터페이스*****

    // 외부 쿼리dsl 함수 이름설정 (QuerydslConfig.java)
    // 함수 이름과 매개변수만 설정

    // 예제 1 : dname like 검색하는 함수 정의
    List<Department> querydslByDname(String dname);

    // 예제 2
    List<Department> querydslByDnameAndLoc(String dname, String loc);


    //////////////////////////////
    // 예제 3  ---> 컨트롤러
    List<DeptGroupQDto> querydslByGroupfunc();


    // 예제 4
    public List<Department> querydslByDeptGt(int dno);

    //////////////////////////////////////////////// 10/31
    // 예제 5
    public List<DeptGroupQDto> QuerydslByBasicFunc();

    // 예제 6
    public List<DeptGroupQDto> QuerydslByCaseWhen();

    // 예제 7
    public List<DeptGroupQDto> querydslByDnoGroup(long dnoCount);

    // 예제 8
    public List<DeptEmpCDto> querydslByDnameJoin(String dname);

    // 예제 8-2
    public List<DeptEmpCDto> querydslByDnameJoin2(String dname);

    // 예제 9
    public List<Department> querydslByDnoSub();

    // 예제 10
    public List<Department> querydslByDnoGoeSub(int dno);


    // 예제 11
    public List<Department> querydslByDynamicName(String dname, String loc);


    }