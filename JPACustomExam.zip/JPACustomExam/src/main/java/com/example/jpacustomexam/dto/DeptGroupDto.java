package com.example.jpacustomexam.dto;

/**
 * packageName : com.example.jpacustomexam.dto
 * fileName : DeptGroupDto
 * author : juhee
 * date : 2022-10-24
 * description : 그룹함수 용도 DTO 인터페이스
 * 쿼리메소드 에서 그룹함수를 지원하지 않으므로, 담을 그릇(클래스)로 (모델_(Dept 객체)  과 유사한) DTO 클래스 생성
 *  DTO : Data Transfer Object 내부 전송용 클래스. 가공된 추가 데이터를 담을 클래스
 * nativeQuery를 사용할 경우, DTO 를 인터페이스로 만듦(안에 getter만 정의)_ 프로젝션이라고 함
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
public interface DeptGroupDto {

    // 예제 3
    // getter함수 형태로 만듦
    // sum
    Integer getSumVar();
    // avg
    Double getAvgVar();
    // max
    Integer getMaxVar();
    // min
    Integer getMinVar();


    // 예제 4
    // 여기에 담는 것
    // "dnoVar": "부서번호는 40",
    // "dnameVar": "부서명은 OPERATIONS",
    // "locVar": "부서위치는 BOSTON",
    // "textVar": "모든 부서정보를 출력했습니다."
    String getDnoVar();
    String getDnameVar();
    String getLocVar();
    String getTextVar();


    // 예제 5
    // upper(dname), lower(dname), length(dname), substr(dname, 1, 2)
    String getUpperDname();
    String getLowerDname();
    String getLengthDname();
    String getStringDname();
    // 추가 (trim, trunc, to_char)
    String getTrimDname();
    String getTruncDname();
    String getCharDname();

    // 예제 6
    String getINCENTIVE();
}
