package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.model.exam04.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Query dsl 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Emp07Repository extends JpaRepository<Employee, Integer>, Emp07RepositoryCustom {

// JPA 함수와 쿼리dsl 함수 같이 쓸 수 있도록 둘다 상속받음*****

        // 여기 바로 네이티브쿼리 넣었지만.. 쿼리dsl 사용을 위해 Dept07RepositoryCustom 를 상속받음
        // 작성은 Emp07Repository만 상속받은 곳(Emp07RepositoryCustomImpl)에서 함

}



