package com.example.jpacustomexam.service.exam07;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.repository.exam07.Dept07Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * packageName : com.example.jpacustomexam.service.exam07
 * fileName : Dept07Service
 * author : juhee
 * date : 2022-10-27
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
@Service
public class Dept07Service {

    @Autowired
    Dept07Repository deptRepository;

    // 예제 1)
    //    조인 결과 쿼리 함수
    public List<Department> querydslByDname(String dname) {
        List<Department> list = deptRepository.querydslByDname(dname);

        return list;
    }

    // 예제 2)
    //    조인 결과 쿼리 함수
    public List<Department> querydslByDnameAndLoc(String dname, String loc) {
        List<Department> list = deptRepository.querydslByDnameAndLoc(dname, loc);

        return list;
    }


    // 예제 3)
    //    조인 결과 쿼리 함수 : 쿼리 dsl*****
    public List<DeptGroupQDto> querydslByGroupfunc() {
        List<DeptGroupQDto> list = deptRepository.querydslByGroupfunc();

        return list;
    }


    // 예제 4)
    //    조인 결과 쿼리 함수
    public List<Department> querydslByDeptGt(int dno) {
        List<Department> list = deptRepository.querydslByDeptGt(dno);

        return list;
    }

    // 10/31
    // 예제 5)
    public List<DeptGroupQDto> QuerydslByBasicFunc() {
            List<DeptGroupQDto> list = deptRepository.QuerydslByBasicFunc();

        return list;
    }

    // 예제 6)
    public List<DeptGroupQDto> QuerydslByCaseWhen() {
            List<DeptGroupQDto> list = deptRepository.QuerydslByCaseWhen();

        return list;
    }

    // 예제 7)
    public List<DeptGroupQDto> querydslByDnoGroup(long dnoCount) {
            List<DeptGroupQDto> list = deptRepository.querydslByDnoGroup(dnoCount);

        return list;
    }

    // 예제 8) 조인
    // DB 트랜잭션 : 함수 안에 insert/update/delete 가 여러 개 섞여 있는 경우, (select 문 말고) 데이터 무결성을 위해
    //              모든 sql문이 작성되고 나서 "마지막에 commit 실행"해서 작동하는 방식. 연관된 sql 들 한 묶음으로, 하나의 로직!(한줄씩 커밋하면 오동작 날 수 있으니)
    // @Transactional : 스프링부트에서 DB 트랜잭션을 지원하는 어노테이션
    // JPA 의 경우, 조인을 사용할 때 이 어노테이션 많이 사용
    @Transactional
    public List<DeptEmpCDto> querydslByDnameJoin(String dname) {
            List<DeptEmpCDto> list = deptRepository.querydslByDnameJoin(dname);

        return list;
    }


    // 예제 8-2) 조인
    @Transactional
    public List<DeptEmpCDto> querydslByDnameJoin2(String dname) {
            List<DeptEmpCDto> list = deptRepository.querydslByDnameJoin2(dname);

        return list;
    }

    // 예제 9 서브쿼리
    @Transactional
    public List<Department> querydslByDnoSub() {
            List<Department> list = deptRepository.querydslByDnoSub();

        return list;
    }

    // 예제 10 서브쿼리
    @Transactional
    public List<Department> querydslByDnoGoeSub(int dno) {
            List<Department> list = deptRepository.querydslByDnoGoeSub(dno);

        return list;
    }

    // 예제 11 서브쿼리
    @Transactional
    public List<Department> querydslByDynamicName(String dname, String loc) {
            List<Department> list = deptRepository.querydslByDynamicName(dname, loc);

        return list;
    }

}
