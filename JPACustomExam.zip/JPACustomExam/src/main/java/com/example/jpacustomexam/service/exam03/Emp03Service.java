package com.example.jpacustomexam.service.exam03;

import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.repository.exam03.Emp03Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.service.exam03
 * fileName : Emp03Service
 * author : juhee
 * date : 2202-10-25
 * description :  Emp 서비스 클래스 ( 업무 로직 짜는 클래스 )
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2202-10-25         juhee          최초 생성
 */
@Service
public class Emp03Service {

    @Autowired
    Emp03Repository empRepository;  // JPA CRUD 함수가 있는 인터페이스 객체

    // 1
    public Page<Emp> findAll(Pageable pageable){
        // findAll : 쿼리 메소드 안만들어도 됨(내장함수)
        Page<Emp> page = empRepository.findAll(pageable); // findAll(페이징객체) 있음

        return page;
    }

    // 2
    public Page<Emp> findAllByOrderByEnameDesc(Pageable pageable){
        Page<Emp> page = empRepository.findAllByOrderByEnameDesc(pageable);
        return page;
    }

    // 3
    public Page<Emp> findAllBySalaryBetween(int first, int last,
                                            Pageable pageable){
        Page<Emp> list = empRepository.findAllBySalaryBetweenAndCommissionIsNotNull(first, last, pageable);
        return list;
    }

    // 4
    public Page<Emp> findAllByEnameContaining(String ename, Pageable pageable){
        Page<Emp> list = empRepository.findAllByEnameContaining(ename, pageable);
        return list;
    }

    // 5
    public Page<Emp> findAllByDnoAndSalaryGreaterThanEqual(int dno, int salary,
                                                           Pageable pageable){
        Page<Emp> list = empRepository.findAllByDnoAndSalaryGreaterThanEqual(dno, salary, pageable);
        return list;
    }

    // 6
    public Page<Emp> selectBySalaryPage(int first, int last, Pageable pageable){
        Page<Emp> list = empRepository.selectBySalaryPage(first, last, pageable);
        return list;
    }


    // 7
    public Page<Emp> selectByHiredatePage(String start, String end,
                                          Pageable pageable){
        Page<Emp> list = empRepository.selectByHiredatePage(start, end, pageable);
        return list;
    }


    // 8
    public Page<Emp> selectBySalaryDnoPage(int first, int last, int dno1, int dno2,
                                          Pageable pageable){
        Page<Emp> list = empRepository.selectBySalaryDnoPage(first, last, dno1, dno2, pageable);
        return list;
    }


    // 9
//    public Page<Emp> selectByHiredateBetween(int start, int last,
//                                          Pageable pageable){
//        Page<Emp> list = empRepository.selectByHiredateBetween(start, last, pageable);
//        return list;
//    }
    public Page<Emp> selectByHiredateContainingPage(int hiredate, Pageable pageable){
        Page<Emp> list = empRepository.selectByHiredateContainingPage(hiredate, pageable);
        return list;
    }


    // 10
    public Page<Emp> selectByCommission(int commission ,Pageable pageable){
        Page<Emp> list = empRepository.selectByCommission(commission, pageable);
        return list;
    }


}
