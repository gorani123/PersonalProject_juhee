package com.example.jpacustomexam.service.exam01;

import com.example.jpacustomexam.model.Dept;
import com.example.jpacustomexam.repository.DeptRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * packageName : com.example.jpaexam.service.exam01
 * fileName : DeptService
 * author : juhee
 * date : 2022-10-20
 * description : 부서 업무 서비스 클래스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Service : 자동으로 객체 만들어주는 어노테이션
@Service
public class DeptService {
    // 그전에는 DAO를 받았음. 그게 repository로 변경됨
    // 객체 생성
    @Autowired
    DeptRepository deptRepository;  // JPA CRUD 함수가 있는 인터페이스 객체

    // 전체 조회 함수
    // deptRepository. (점) 하면 JPA의 기본함수들 불러서 쓸 수 있음
    public List<Dept> findAll(){
        List<Dept> list = deptRepository.findAll();

        return list;
    }

    // id로 조회 함수
    public Optional<Dept> findById(int dno){
        Optional<Dept> optionalDept = deptRepository.findById(dno);

        return optionalDept; // 리턴 옵션
    }

    // (insert, update 함께)
    // insert 함수
    public Dept save(Dept dept){
        // deptRepository.함수명() : JPA 연결된 객체라 기본내장함수 호출가능
        // JPA.save() 함수의 특징
        // 기본키 값(dno, 부서번호)이 없으면 insert
        // 기본키 값(dno, 부서번호)이 있으면 update
        Dept dept2 = deptRepository.save(dept); // insert 함수(기본값없으면 삽입)

        return dept2;
    }


    // id(부서번호)로 삭제하는 함수 ////////////////////////////////
    // 제공하는 기본함수(deleteById(id)), 리턴값 없음(void) --> 제공함수 .existsById 이용, 리턴값 boolean으로 변경
    // 삭제 결과 없으면 false, 1건 이상이면 true
    public boolean removeById(int id){

        // id에 해당하는 값이 있는지 select 해서, 있으면 delete, true
        // 없으면 스킵, false
        if(deptRepository.existsById(id) == true){
            // true면(id값 있으면)
            deptRepository.deleteById(id);  // id에 해당하는 데이터정보 삭제
            return true;
        } else {
            return false;
        }
    }


//     쿼리 메소드 연습
//    연습예제
    public List<Dept> findAllDesc(){
        List<Dept> list = deptRepository.findAllByOrderByDnoDesc(); // 전체 조회(dno, 내림차순)

        return list;
    }

    // 연습문제 1
    public List<Dept> findAllDnameDesc(){
        List<Dept> list = deptRepository.findAllByOrderByDnameDesc(); // 전체 조회(dno, 내림차순)

        return list;
    }

    // 연습문제 2
    public List<Dept> findAllLikeDname(String dname){
        List<Dept> list = deptRepository.findAllByDnameContainingOrderByDnameDesc(dname); // 전체 조회(dno, 내림차순)

        return list;
    }

    // 연습문제 3
    public List<Dept> findAllAsc(){
        List<Dept> list = deptRepository.findAllByOrderByDnoAsc(); // 전체 조회(dno, 내림차순)

        return list;
    }



}
