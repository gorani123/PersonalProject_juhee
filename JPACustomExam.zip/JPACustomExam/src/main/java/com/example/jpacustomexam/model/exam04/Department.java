package com.example.jpacustomexam.model.exam04;

import com.example.jpacustomexam.model.BaseTimeEntity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * packageName : com.example.jpacustomexam.model.exam04
 * fileName : Department
 * author : juhee
 * date : 2022-10-27
 * description : 조인(join) 실습을 위한 부서 클래스. 관계 맺기 @ManyToOne(***) / @OneToMany / @ManyToMany / @OneToOne
 *                                                       현재테이블, @OneToMany  (1:다수    부서 1 - 사원 다수 )
 *
* @ManyToOne  (자바 jpa 클래스에서만 나오는 개념_단방향/양방향 조합 총 6가지) (*참고_DB 모델링, 3가지_1:1/1:다(다:1)/다:다)
 *    - 단방향 조인 (추천) : 부서클래스에 @OneToMany 달지 않음. ***사원클래스에 @ManyToOne 달기
 *    - 양방향 조인 (꼭 필요하다면 사용) : 부서클래스에 @OneToMany 달기. 사원클래스에 @ManyToOne 달기
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
@Entity
@Table(name="TB_DEPARTMENT")       // 테이블명 ***
@SequenceGenerator(                 //👀 아래 @GenerateValue()에서 써준거 세부적으로 써줘야 함
        name= "SQ_DEPARTMENT_GENERATOR",
        sequenceName = "SQ_DEPARTMENT",
        initialValue = 1,
        allocationSize = 1
)
@Getter
@Setter
@ToString(exclude = "department")   // ""안의 값속성) 모시해하라
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicInsert
@DynamicUpdate
public class Department extends BaseTimeEntity{
    // 속성
    // @Id : 기본키(PrimaryKey). not null. 유일해야 함 (하나는 필수. 없으면 클래스명(Detp)에 빨간줄 뜸)
    // @GenerateValue(..SEQUENCE, ...) :오라클은 시퀀스 사용함 (시퀀스 사용_ORACLE, POSTGRE 등/ increment 사용_MYSQL, MARIA DB 등)
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_DEPARTMENT_GENERATOR") //👀
    private Integer dno;     // 부서번호(dno)

    @Column(columnDefinition = "VARCHAR2(255)")
    private String dname;    // 부서명(dname)

    @Column(columnDefinition = "VARCHAR2(255)")
    private String loc;      // 위치(loc)


    // 양방향 관계를 위한 설정
    // 양방향 관계의 특징
    //      1) Many쪽(다수) 클래스에 @ManyToOne 추가 : 실제 데이블의 dno컬럼이 생성되고 FK도 생성됨. FK를 관리하는 클래스(주인클래스)
    //      2) Ooe쪽(다수) 클래스에 @OneToMany 추가 : 컬럼 생성 안됨. FK없음, 클래스에만 속성이 있음
    // @OneToMany(mappedBy = "department") : 사원 클래스(모델-Employee)의 @ManyToOne 달린 곳의 속성 department 입력
    //    @ManyToOne(fetch = FetchType.LAZY)
    //    @JoinColumn(name="dno")
    //    @JsonBackReference
    //    private Department department;
    @OneToMany(mappedBy = "department")
    @JsonManagedReference
    private Set<Employee> employee = new HashSet<>(); // list ->  set , (중복제거)
//    private List<Employee> employeeList = new ArrayList<>();    // 배열을 만드는 이유 : 사원이 다수라서

}

// 10/28 만드는 순서*****  (별다섯개로 검색)
// model(exam04폴더의 Department) ->  Dept07Repository
// -> Dept07RepositoryCustom -> (QUerydslConfig) ->  Dept07RepositoryCustomImpl  --> DeptGroupQDto(가공데이터 출력하려고 만듦) --> Dept07RepositoryCustomImpl
// -> Dept07Service(07리파지토리 함수 받아서 정의)  -> Dept07Controller(07서비스의 함수 불러와서 실행)