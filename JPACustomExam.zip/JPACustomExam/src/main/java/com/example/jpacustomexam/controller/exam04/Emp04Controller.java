package com.example.jpacustomexam.controller.exam04;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.DeptEmpDto;
import com.example.jpacustomexam.service.exam04.Dept04Service;
import com.example.jpacustomexam.service.exam04.Emp04Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * packageName : com.example.jpaexam.controller.exam07
 * fileName : Dept07Controller
 * author : juhee
 * date : 2022-10-21
 * description : 부서 컨트롤러 (@RestController) ------ 여기서부터 중요
 * 요약 : 😦
 *      사용자 정의(custom) 함수 _ Repository에 작성
 *   1. 쿼리 메소드 : 자동으로 사용자정의 sql 문을 작성하기 위해 사용
 *      목적 : 기본 함수보다 다양한 sql문을 작성하기 위해 사용
 *      사용법 : 함수이름으로 sql 문장을 작성함 ( Repository 안에 함수명만 작성 )
 *      ex) JPA 클래스 === 대상 테이클
 *      ex) find == select
 *      ex) all = *
 *      ex) by == from
 *      ex) 속성 = where 컬럼
 *      ex) orderBy == order by
 *      ex) 속성 desc = 컬럼 desc
 *
 *   2. @Query(쿼리문)함수명() : 쿼리문에 해당되는 부분을 직접 개발자가 작성(sql문)
 *      쿼리문의 매개변수 전달 ->👀 :변수   => 함수명(@Param("변수") String 변수
 *      select * from tb_dept where dno = :변수명
 *      List<Dept> selectAll(@Param(변수명) 타입 변수명
 *
 *       2-1) nativeQuery = true : 일반 sql 문으로 작성
 *       2-2) nativeQuery = false, 생략 : 객체 쿼리
 *                                      ( 테이블명, 컬럼명 대신 클래스명, 속성(필드명) 사용 )
 *
 *   3. 페이징 처리 함수
 *      목적 : 전체 데이터를 화면에 출력하면 성능과 가독성이 떨어지므로, 몇 건씩 끊어서 보여주는 것
 *      페이징 객체 :
 *          1) 매개변수 페이징 객체 : Pageable
 *          2) 리턴될 페이징 객체 : Page<객체자료형>
 *      속성 : page = 현재페이지(0부터 시작) , size = 한 페이지에 보여 줄 데이터 수 (url 매개변수로 전달됨)
 *      클라이언트로 전송 할 데이터 : Map 자료구조 이용
 *          1) 데이터: 부서, 사원 등
 *          2) currentPage : 현재 페이지 수(정보) (총 10페이지 중 현재 3페이지에 위치)
 *          3) totalItem : 전체 데이터 수
 *          4) totalPages : 전체 페이지 수
 *
 *  조인, 동적쿼리
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-21         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam04")
public class Emp04Controller {

//     스프링부트가 가동될 때 자동생성된 서비스 객체를 @AUtowired 로 받아오기(new 연산자로 직접 생성하는 대신)
//     DI(의존성 주입_위와 같은 말) (@Autowired)
    @Autowired
    Emp04Service deptService;

    // 네이티브 쿼리 이용 조인 함수
    @GetMapping("/dept/native/join/ename/{ename}")
    public ResponseEntity<Object> getEmpNativeJoinEname(@PathVariable String ename){

        try {
            List<DeptEmpDto> list = deptService.selectNativeJoinEname(ename);

            if (list.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
//            서버 에러
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



}



