package com.example.jpacustomexam.repository.exam03;

import com.example.jpacustomexam.model.Emp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * packageName : com.example.jpaexam.repository
 * fileName : EmpRepository
 * author : juhee
 * date : 2022-10-20
 * description : EMP 리파지토리(==DAO) CRUD용 함수가 있는 인터페이스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Emp클래스의 기본키인 @ID 속성
@Repository
public interface Emp03Repository extends JpaRepository<Emp, Integer> {

//     👀쿼리 메소드!!!를 이용하여 작성하세요 //////////////////////////////////////#################################
    // 1) Emp 테이블을 전체 조회하는 findAll() 함수에 페이징 처리 로직을 추가하세요
    // findAll(Pageable pageable) 기본함수로 제공하므로 쿼리메소드 만들 필요 없음

    // 2) ename으로 내림차순 정렬해서 전체 사원 정보를 출력하는 함수를 정의하세요(단, 페이징 처리 로직을 추가하세요.)
    Page<Emp> findAllByOrderByEnameDesc(Pageable pageable);
//                // 어노테이션 쿼리
//                // sql : select * from tb_emp order by ename;
//                @Query(value = "select e.* from tb_emp order by ename"
//                        , countQuery = "select count(*) from tb_emp e "
//                        , nativeQuery = true)
//                Page<Emp> selectBy(Pageable pageable);


    // 3) salary 가 1000 ~ 1500 사이이고 Commission 이 not null 일 때 함수를 정의하세요.(단, 페이징 처리 로직을 추가하세요.)
    // select * from tb_emp where salary between 1000 and 1500 and commission is not null;
    // between 사용
    Page<Emp> findAllBySalaryBetweenAndCommissionIsNotNull(int first, int last, Pageable pageable);


    // 4) ename like 검색하고 결과를 페이징하는 함수를 작성하세요. (단, 페이징 처리 로직을 추가하세요.)
    // like - Containing
    Page<Emp> findAllByEnameContaining(String ename, Pageable pageable);

    //  5) 10번 부서에 해당하고 salary 가 1000 이상인 결과를 조회하는 함수를 작성하세요. 단, 페이징 처리 로직을 추가하세요.
    // like(Containing) 는 문자열만
    // findAllByDnoContainingSalaryGreaterThan : 틀림
    // Dno=10 이고 And salary>=1000
    Page<Emp> findAllByDnoAndSalaryGreaterThanEqual(int dno, int salary, Pageable pageable);


//    👀어노테이션 쿼리!!를 이용하여 작성하세요 //////////////////////////////////////#################################

    // 6) 급여가 2000~3000 사이에 포함되지 않는 사원을 출력하는 함수(단, 페이징 처리 로직 추가)
    // select * from tb_emp where salary not between 2000 and 3000;
    // nativeQuery = true 일 경우 (일반 sql문) countQUery 필요
    @Query(value = "select e.* from tb_emp e where e.salary not between :first and :last "
            , countQuery = "select count(*) from tb_emp e where e.salary not between :first and :last"
            , nativeQuery = true)

    Page <Emp> selectBySalaryPage(@Param("first") int first,
                                  @Param("last") int last, Pageable pageable);


    // 7) 1981년 2월 20일부터 1981년 5월 1일 사이 입사한 사원을 출력하는 함수(단, 페이징 처리 로직 추가)
    // select * from tb_emp where hiredate between '1981-02-20' and '1981-05-01';
    @Query(value = "select e.* from tb_emp e where e.hiredate between :start and :end"
            , countQuery = "select count(*) from tb_emp e where e.hiredate between :start and :end"
            , nativeQuery = true)

    Page <Emp> selectByHiredatePage(@Param("start") String start,
                                    @Param("end") String end, Pageable pageable);


    // 8) 월 급여 1000~3000 사이의 사원 중 부서번호 10, 20 번인 사원을 출력하는 함수(단, 페이징 처리 로직 추가)
    // 매개변수 두개 받아서 출력
    // select * from tb_emp where e.salary between 1000 and 3000 and e.dno in (10, 20);
    @Query(value = "select * from tb_emp e where e.salary between :first and :last and e.dno in (:dno1, :dno2)"
            , countQuery = "select count(*) from tb_emp e where e.salary between :first and :last and dno in (:dno1, :dno2)"
            , nativeQuery = true)

    Page <Emp> selectBySalaryDnoPage(@Param("first") int first,
                                     @Param("last") int last,
                                     @Param("dno1") int dno1,
                                     @Param("dno2") int dno2, Pageable pageable);


    // 9) 1981년에 입사한 사원을 출력하는 함수(단, 페이징 처리 로직 추가)
    // select * from tb_emp where hiredate between '1981-01-01' and '1981-12-31';
//    @Query(value = "select e.* from tb_emp e where e.hiredate between :start and :last"
//            , countQuery = "select count(*) from tb_emp e where e.hiredate between :start and :last"
//            , nativeQuery = true)
//
//    Page <Emp> selectByHiredateBetween(@Param("start") int start,
//                                 @Param("last") int last, Pageable pageable);

    // select * from tb_emp where hiredate like '%1981%';
    @Query(value = "select e.* from tb_emp e where e.hiredate like %:hiredate%"
            , countQuery = "select count(*) from tb_emp e where e.hiredate like %:hiredate%"
            , nativeQuery = true)
    Page <Emp> selectByHiredateContainingPage(@Param("hiredate") int hiredate, Pageable pageable);



    // 10) 커미션(commission)이 500 이상인 사원의 정보 출력하는 함수(단, 페이징 처리 로직 추가)
    // select * from tb_emp where commission >= 500;
    @Query(value = "select e.* from tb_emp e where e.commission >= :commission"
            , countQuery = "select count(*) from tb_emp e where e.commission >= :commission"
            , nativeQuery = true)

    Page <Emp> selectByCommission(@Param("commission") int commission, Pageable pageable);


}
