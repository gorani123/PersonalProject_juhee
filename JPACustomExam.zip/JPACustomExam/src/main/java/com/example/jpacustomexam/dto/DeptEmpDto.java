package com.example.jpacustomexam.dto;

/**
 * packageName : com.example.jpacustomexam.repository.exam04
 * fileName : DeptEmpDto
 * author : juhee
 * date : 2022-10-27
 * description : native Query로 Dept와 Emp 이퀄조인 한 결과를 저장할 DTO 인터페이스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
public interface DeptEmpDto {

    // (기존 모델에 속성을 담을 수 없어서) 중간역할을 하는 자료를 담는 객체 DTO
    // 결과값 저장할 함수 : getter 함수 형태로 만듦

    // 부서
    Integer getDno();
    String getDname();
    String getLoc();

    // 사원
    Integer getEno();
    String getEname();
    Integer getSalary();

}
