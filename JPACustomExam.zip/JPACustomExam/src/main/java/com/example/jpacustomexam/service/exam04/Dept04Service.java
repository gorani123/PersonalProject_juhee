package com.example.jpacustomexam.service.exam04;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.DeptEmpDto;
import com.example.jpacustomexam.repository.exam04.Dept04Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * packageName : com.example.jpaexam.service.exam01
 * fileName : DeptService
 * author : juhee
 * date : 2022-10-20
 * description : 부서 업무 서비스 클래스
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Service : 자동으로 객체 만들어주는 어노테이션
@Service
public class Dept04Service {
    // 객체 생성
    @Autowired
    Dept04Repository deptRepository;  // JPA CRUD 함수가 있는 인터페이스 객체


    // 1-1 조인 결과 쿼리 함수 : 네이티브 쿼리 이용
    public List<DeptEmpDto> selectNativeJoin(){
        List<DeptEmpDto> list = deptRepository.selectNativeJoin();

        return list;
    } 
    
    // 1-2 조인 결과 쿼리 함수 : 객체 쿼리 이용
    public List<DeptEmpCDto> selectJoin(){
        List<DeptEmpCDto> list = deptRepository.selectJoin();

        return list;
    }


}
