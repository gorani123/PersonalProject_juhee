package com.example.jpacustomexam.repository.exam04;

import com.example.jpacustomexam.dto.DeptEmpDto;
import com.example.jpacustomexam.model.Dept;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * packageName : com.example.jpaexam.repository
 * fileName : DeptRepository
 * author : juhee
 * date : 2022-10-20
 * description : Join 실습 repository
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-20         juhee          최초 생성
 */
// @Repository : 서버가 기동될 떄 객체를 자동으로 생성해 주는 어노테이션(@Service, @Component, @Repository)
// extends JpaRepository<모델(엔터티)명, @ID 붙은 곳의 속성자료형(객체형태)> : JPA 인터페이스를 상속받아야 CRUD 함수 사용 가능
//                                     model폴더의 Dept클래스의 기본키인 @ID 속성
// JpaRepository<모델, 기본키속성타입(자료형)>
@Repository
public interface Emp04Repository extends JpaRepository<Dept, Integer> {

    // 문제 1
//    employee 와 department 테이블을 조인한 뒤 ename(사원명) like 검색하는 함수를 작성
//    nativeQuery, 객체쿼리 중 선택
    // sql : select d.*, e.eno, e.ename, e.salary from tb_employee e, tb_department d where e.dno = d.dno and e.ename like '%SC%';

    @Query(value = " select d.*, e.eno, e.ename, e.salary " +
            "        from tb_employee e, tb_department d " +
            "        where e.dno = d.dno " +
            "        and e.ename like %:ename%"
            , nativeQuery = true)
    List<DeptEmpDto> selectNativeJoinEname(@Param("ename") String ename);

}


