package com.example.jpacustomexam.repository.exam07;

import com.example.jpacustomexam.dto.DeptEmpCDto;
import com.example.jpacustomexam.dto.querydsl.DeptGroupQDto;
import com.example.jpacustomexam.model.QDept;
import com.example.jpacustomexam.model.QEmp;
import com.example.jpacustomexam.model.exam04.Department;
import com.example.jpacustomexam.model.exam04.QDepartment;
import com.example.jpacustomexam.model.exam04.QEmployee;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.CaseBuilder;
import com.querydsl.jpa.JPAExpressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.repository.exam07
 * fileName : Dept07RepositoryCustomImpl
 * author : juhee
 * date : 2022-10-27
 * description : 쿼리dsl 함수를 정의하는 곳
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-27         juhee          최초 생성
 */
// dept07RepositoryCustom을 상속받아야 객체 가져옴 *****
public class Dept07RepositoryCustomImpl implements Dept07RepositoryCustom{

    // JPAQueryFactory는 외부 쿼리dsl 라이브러리 설치시 자동으로 생성. 그 객체 가져옴. ***
    @Autowired
    private JPAQueryFactory queryFactory;


    // 쿼리dsl에서 자동으로 객체 만들어 줌**
    // gradle -> other -> compileQuerydsl 클릭해야 만들어줌
    // Querydsl 을 위한 Q객체 가져오기 - 속성(department, employee) 불러오기
    private QDepartment department = QDepartment.department;
    private QEmployee employee = QEmployee.employee;

    // Querydsl 을 위한 Q객체 가져오기 - 속성(dept, emp) 불러오기 : 예제 8-2에서 이용
    // 원본은 두고 복사본만 이용하는 거임!!
    private QDept dept = QDept.dept;
    private QEmp emp = QEmp.emp;

    // 아래 예제들,  쿼리dsl을 이용해서 만든 함수들. ***
    // dept07RepositoryCustom을 상속받아야 객체 가져와서 그 객체 안에 정의할 수 있음



//    예제 1 : dname like 검색하는 함수 정의
//    체이닝 이용: .함수().함수()
    @Override
    public List<Department> querydslByDname(String dname){

        List<Department> list = queryFactory
                .selectFrom(department)                     // select문
                .where(
                        department.dname.contains(dname)    // like검색
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    // 예제 2 : Dname & Loc 로 like 검색하는 함수
    @Override
    public List<Department> querydslByDnameAndLoc(String dname, String loc) {

//        querydsl 사용법 :
//        queryFactory.selectFrom().where(조건).fetch();
//                     select *     조건: departmemt.속성.연산자(값)
//                                                       연산자: in(), gt() ~보다크다, lt() ~보다작다, eq() 같다

//        queryFactory.select(DTO(컬럼1, 컬럼2,...)).where(조건).orderBy().fetch();
//                     select dname                           .groupBy()
//                                                            .and() (,로 써도 됨)
//                                                            .or()


//        select * from tb_department where dname like '%%' and loc like '%%';
        List<Department> list = queryFactory
                .selectFrom(department)             // select문
                .where(
                        department.dname.contains(dname)    // like검색
//                      ,department.loc.contains(loc)       //and 대신 바로 ,써도 됨
                                .and(department.loc.contains(loc))    // and loc like '%%'
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    //////////////////////////////////////////////////////////////////////////////////////// 찬찬히 읽기 ////////////////
    ////////////////////////////////   10/28    ///////////////////////////////////////////////////////////////////////
    // 예제 3 : 부서테이블의 부서번호를 sum, avg, max, min 값을 출력하는 예제 (+ count)
    @Override
    public List<DeptGroupQDto> querydslByGroupfunc(){

        // 출력할 속성을 dto에 넣으니까 리턴값도 DeptGroupQDto 로 변경 *****
        List<DeptGroupQDto> list = queryFactory
//                속성 몇개만 select(출력) 할 때는 DTO 클래스 이용 (DTO 인터페이스 -> native query) (DTO 클래스 -> 객체쿼리, 쿼리dsl)
//                **dto에 querydsl 폴더에 DeptGroupQDto 만들기(sum, avg, max, min, count 속성 이 안에 정의)
//                 DTO : 속성 몇 개만 출력하거나, 가공된 데이터(그룹함수)를 출력하고 싶을 때 사용
//                      1) DTO 생성자를 이용해서 속성으로 저장(출력) : new 생성자(속성1, 속성2, ...)
//                      2) 이미 있는 속성을(필드) 이용해서 출력 : Projections.fields(DTO객체, 속성1, 속성2, ..속성들..)
                .select(
                        Projections.fields(
                                DeptGroupQDto.class,
                                department.dno.count().as("countVar"),      // 자료는 department꺼 그대로 사용
                                department.dno.sum().as("sumVar"),          // DeptGroupQDto 의 속성 순서대로 입력!!
                                department.dno.avg().as("avgVar"),
                                department.dno.max().as("maxVar"),
                                department.dno.min().as("minVar")
                        )
                )
                .from(department)                   // (selectFrom = select All)
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    
    // 예제 4 : 부서번호가 20보다 큰 부서들의 정보를 출력  -> 정의 후 Dept07RepositoryCustom 리파지토리 인터페이스로 가서 구현 -> service -> controller
    @Override
    public List<Department> querydslByDeptGt(int dno){

        List<Department> list = queryFactory
                .selectFrom(department)             // select문
                .where(
                        department.dno.gt(dno)      // .gt() : greater than ~보다 큰 (<-> .lt() : less than)
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    // 예제 5 : sql 기본 내장함수를 사용하는 함수를 작성
    // 대소문자 바꾸기 : UPPER() , LOWER()
    // 문자열 자르기 : SUBSTR()
    // 가공된 결과 -> dto 사용
    @Override
    public List<DeptGroupQDto> QuerydslByBasicFunc() {

        // QueryDto 사용법:
        //          1) 속성에 바로 저장 : Projections.fields(DTO클래스, 속성...)
        //          2) 생성자를 이용해 저장 :  new Dto 클래스(쏙성...)
        // substr(인덱스번호, 길이) / substring(처음인덱스번호, 끝인덱스번호)
        List<DeptGroupQDto> list = queryFactory
                .select(
                        Projections.fields(
                                DeptGroupQDto.class,
                                department.dname.upper().as("upperDname"),          //"별칭" - 컬럼명처럼 사용
                                department.dname.lower().as("lowerDname"),
                                department.dname.substring(1, 2).as("substrDname")  // (인덱스번호_1부터시작, 자를 문자열개수)

                        )
                )
                .from(department)
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }


    // 예제 6 : Case When
    @Override
    public List<DeptGroupQDto> QuerydslByCaseWhen() {

        List<DeptGroupQDto> list = queryFactory
                .select(
                        Projections.fields(
                                DeptGroupQDto.class,
                                // Case When 부분 작성
                                // new CaseBuilder().when(조건식).then(실행)
                                //              .when(조건식).then(실행)
                                //              .otherwise().as(별칭)
                                new CaseBuilder()
                                        .when(department.dno.lt(20)).then("인센티브 100%")     // dno<20
                                        .when(department.dno.gt(20)).then("인센티브 200%") // dno>20
                                        .otherwise("인센티브 없음").as("caseString")        // dno=20
                                                            // QDto에 caseString 속성 추가하기
                        )
                )
                .from(department)
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    // 예제 7 : 그룹함수 group by 예제
    // 부서번호(dno)가 10, 20에 해당하는 부서의 갯수(count)를 출력
    // Querydsl 은 count()함수의 리턴값의 자료형이 long(Long) 임!!!👀
    @Override
    public List<DeptGroupQDto> querydslByDnoGroup(long dnoCount){

        List<DeptGroupQDto> list = queryFactory
                .select(
                        Projections.fields(                           // select 절
                                DeptGroupQDto.class,                  // select dno, count(dno) from tb_Department
                                department.dno.as("dno"),               // DeptGroupQDto에 속성으로 dno 추가
                                department.dno.count().as("dnoCount")   // 속성으로 dnoCount 추가
                        )
                )
                .from(department)                  
                .where(
                        department.dno.in(10,20)      // where dno in (10, 20)      여기서 두건 출력
                )
                .groupBy(department.dno)      // dno로 그루핑    // groub by dno
                // 아래는 참고(group by 결과에 대한 조건절)
                .having(department.dno.count().eq(dnoCount))    // having count(dno) = 1;  dnoCount 결과값에 1을 넣으면
                .fetch();       // 조회 실행. 마지막에 항상 실행
        return list;

                                                                // dnoCount = 1 을 주면 dno에 1 들어가는 데이터를 찾음 .
                                                                // dno=10 인 데이터가 하나니까 dnoCount = 1임. (속성으로 출력됨)
                                                                // 자료 자체는 2건 출력(그룹으로 dno가 10 또는 20인 데이터 출력)
    }


    // 예제 8 : dname 조인(join)
    // select e.eno, e.ename, e.job, d.dname, d.loc
    // from tb_employee e,
    //      tb_department d
    // where e.dno = d.dno      이퀄조인 (=leftjoin)
    // and   d.dname like '%%';
    //                          leftjoin(employee의 @ManyToOne 달린 속성명, 조인될 객체명)
    @Override
    public List<DeptEmpCDto> querydslByDnameJoin(String dname){

        List<DeptEmpCDto> list = queryFactory
                .select(
                        Projections.fields(
                                DeptEmpCDto.class,          // select 할 속성 넣기
                                employee.eno.as("eno"),
                                employee.ename.as("ename"),
                                employee.job.as("job"),
                                employee.hiredate.as("hiredate"),
                                employee.salary.as("salary"),
                                employee.department.dname.as("dname"),  // 조인될 컬럼 dname
                                employee.department.loc.as("loc")

                        )
                )
                .from(employee)
                // leftjoin(employee의 @ManyToOne 달린 속성명, 조인될 객체명)
                .leftJoin(employee.department, department)  // employee의 department와  department 조인
                .where(
                        department.dname.contains(dname)    // like검색
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    // 예제 8-2 : 연관관계 없는 모델 조인 (모델에 @ManyToOne, @OneToMany 없는 조인)
    // build - generated - querydsl - com.example.jpa... - exam05 - QDept/Qemp
    // Querydsl 을 위한 Q객체 가져오기 - 속성(dept, emp) 불러오기
    // 원본은 두고 복사본만 이용하는 거임!!
//    private QDept dept = QDept.dept;
//    private QEmp emp = QEmp.emp;
    @Override
    public List<DeptEmpCDto> querydslByDnameJoin2(String dname){

        List<DeptEmpCDto> list = queryFactory
                .select(
                        Projections.fields(
                                DeptEmpCDto.class,          // select 할 속성 넣기
                                emp.eno.as("eno"),
                                emp.ename.as("ename"),
                                emp.job.as("job"),
                                emp.hiredate.as("hiredate"),
                                emp.salary.as("salary"),
                                dept.dname.as("dname"),  // 연관관계 없는 애들 바로 접근가능
                                dept.loc.as("loc")       // 연관관계 없는 애들 바로 가져옴

                        )
                )
                .from(emp)
                // .join(조인객체명).on(이퀄조인조건: 객체명1.공통속성명.eq(객체명2.공통속성명) )
                .join(dept).on(emp.dno.eq(dept.dno))  // equal 조인
                .where(
                        dept.dname.contains(dname)    // like검색
                )
                .fetch();       // 조회 실행. 마지막에 항상 실행

        return list;
    }

    // 예제 9 : 서브쿼리 (select 안의 조건문에 select 문이 들어있는 경우)
    // 부서번호가 부서번호 평균보다 작은 데이터
    @Override
    public List<Department> querydslByDnoSub() {

//        subquery 를 위한 Q객체 따로 생성
//        사용법 : 1) Q클래스명 서브객체명 = new Q생성자(별명);
//                2) JPAExpressions.selectFrom(서브객체명)함수 호출
        QDepartment subDept = new QDepartment("subDept");

        // sql문 : select * from tb_dept
        //       where dno <= (select avg(dno) from tb_dept);
        List<Department> list = queryFactory
                .selectFrom(department)
                .where(
                        department.dno.loe(             // loe : less or equal _작거나 같다
                                JPAExpressions.select(subDept.dno.avg())
                                        .from(subDept)
                        )
                )
                .fetch(); // 마지막에 항상 실행(조회 실행)

        return list;
    }

    // 예제 10 : 서브쿼리
    // 부서번호가 매개변수 10(부서번호)보다 같거나 큰 경우
    // sql : select * from tb_department
    //       where dno in (select dno from tb_department where dno >= 10 )
    @Override
    public List<Department> querydslByDnoGoeSub(int dno) {

//        subquery 를 위한 Q객체 따로 생성
//        사용법 : 1) Q클래스명 서브객체명 = new Q생성자(별명);
//                2) JPAExpressions.selectFrom(서브객체명)함수 호출
        QDepartment subDept = new QDepartment("subDept");

        List<Department> list = queryFactory
                .selectFrom(department)
                .where(
                        department.dno.in(
                                JPAExpressions.select(subDept.dno)
                                        .from(subDept)
                                        .where(
                                                department.dno.goe(dno)     // 조건 goe : great or equal _크거나 같다
                                        )
                        )
                )
                .fetch(); // 마지막에 항상 실행(조회 실행)

        return list;
    }


    // 예제 11
    // 동적 쿼리(dynamic query) :  querydsl. 조건에 따라 쿼리문이 달라지는 것
    // 게시판 검색 : 셀렉트박스(제목_title), 내용(content), 작성자(writer)
//    select * from tb_board where title like '%%';
//    select * from tb_board where content like '%%';
//    조건에 따라 쿼리문이 달라지는 것을 동적쿼리라고 함
//    if(title != null) {
//       select * from tb_board where title like '%%';
//    } else {
//      select * from tb_board where content like '%%';
//    }

    @Override
    public List<Department> querydslByDynamicName(String dname, String loc) {

        // 다이나믹 뭐리 작성하기 : BooleanBuilder 클래스에서 동적조건부분(Where 절)을 만들 수 있음
        BooleanBuilder builder = new BooleanBuilder();

        // dname 이 null 이 아니면 where dname like '%dname%' 추가 (like = contains)
        if( dname != null) {
            builder.and(department.dname.contains(dname));
        }
        // loc가 null이 아니면 where loc like '%loc%' 추가
        if( loc != null) {
            builder.and(department.loc.contains(loc));
        }

        return queryFactory
                .selectFrom(department)
                .where(builder) // 위에서 만든 동적으로 만들어지는 where 절 추가 (builder)
                .fetch(); // 조회 실행
    }


}


