package com.example.jpacustomexam.controller.exam01;

import com.example.jpacustomexam.model.Emp;
import com.example.jpacustomexam.service.exam01.EmpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.controller.exam01
 * fileName : EmpController
 * author : juhee
 * date : 2022-10-24
 * description :
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2022-10-24         juhee          최초 생성
 */
//@RestController : 리턴값 json 객체 형태로 출력 (@Controller: 홈페이지로 이동)
//@RequestMapping : 공통 url
@Slf4j
@RestController
@RequestMapping("/exam01")
public class EmpController {

    @Autowired
    EmpService empService;

    // 함수 getEmpAll()
    @GetMapping("/emp")
    public ResponseEntity<Object> getEmpAll() {

        try {
            List<Emp> list = empService.findAll();    // 전체 조회(내림차순)

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }


    // 연습문제 1: 함수 getEmpAllDesc()
    @GetMapping("/emp/desc")
    public ResponseEntity<Object> getEmpAllDesc() {

        try {
            List<Emp> list = empService.findAllDesc();    // 전체 조회(내림차순)

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 2: like 검색 (ename)
    @GetMapping("/emp/like/ename/{ename}")
    public ResponseEntity<Object> getEmpEnameLike(@PathVariable String ename) {

        try {
            List<Emp> list = empService.findAllByEnameContainingOrderByEnameDesc(ename);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    // 연습문제 3: like 검색 (job)
    @GetMapping("/emp/like/job/{job}")
    public ResponseEntity<Object> getEmpJobDesc(@PathVariable String job) {

        try {
            List<Emp> list = empService.findAllByJobContainingOrderByJobDesc(job);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 4 : job이 manager이고, 매개변수로 부서번호(dno)를 전달받음
    @GetMapping("/emp/dno/{dno}")
    public ResponseEntity<Object> getEmpJobDno(@PathVariable int dno) {

        try {
            // job = 'MANAGER' 로 고정임. 그래서 여기서는 매개변수 dno 하나만 받음 (둘다받아도 되긴함)
            // 서비스에서 이미 매개변수 2개 설정했기때문에..
            List<Emp> list = empService.findAllByJobAndDno("MANAGER", dno);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 5 : salary가 1000~1500 사이
    @GetMapping("/emp/between/salary/{first}/{last}")
    public ResponseEntity<Object> getEmpSalaryBetween(@PathVariable int first, @PathVariable int last) {

        try {
            List<Emp> list = empService.findAllBySalaryBetweenOrderByEname(first, last);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 6 : job, 대소문자 무시
    @GetMapping("/emp/job/{job}")
    public ResponseEntity<Object> getEmpJob(@PathVariable String job) {

        try {
            List<Emp> list = empService.findAllByJobIgnoreCase(job);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 7 : commission is not null
    @GetMapping("/emp/commission/")
    public ResponseEntity<Object> getEmpCommissionIsNotNull() {

        try {
            List<Emp> list = empService.findAllByCommissionIsNotNull();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 8 :
    @GetMapping("/emp/salary/desc/ename/asc")
    public ResponseEntity<Object> getEmpOrderby() {

        try {
            List<Emp> list = empService.findAllByOrderBySalaryDescEnameAsc();

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 9 : salary < 1000 or salary > 1500
//    url 설계 표준(REST API 프로그램 개발)
//    1) 소문자, 단어 별로 끊어서 사용(salary than -> salary/than/)
//    2) url 매개변수{} : 앞에 어떤 값이 들어오는지 단어를 적어주면 좋음 (/dno/10)
//    3) 명사를 사용(동사는 거의 사용x)
    @GetMapping("/emp/than/salary/{first}/{second}")
    public ResponseEntity<Object> getSalaryThan(@PathVariable int first,
                                                @PathVariable int second) {

        try {
            List<Emp> list = empService.findAllBySalaryLessThanOrSalaryGreaterThan(first, second);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }

    //  연습문제 10 : salary
    @GetMapping("/emp/commission/{first}/{second}/{last}")
    public ResponseEntity<Object> getSalaryIn(@PathVariable int first,
                                              @PathVariable int second,
                                              @PathVariable int last) {

        try {
            List<Emp> list = empService.findAllByCommissionIsOrCommissionOrCommission(first, second, last);

            // list배열이 비어있지 않으면
            if (list.isEmpty() == false) {
                //                         데이터 + 성공 메시지 전송
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                // 데이터 없음 메시지 클라이언트에게 전송
                return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());    // 로그 확인하는 어노테이션 위에 걸기@Slf4j
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // 서버 에러 발생 메시지 전송(클라이언트로 전송)
        }
    }




}

